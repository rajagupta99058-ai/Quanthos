import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { Maximize2, Minimize2 } from "lucide-react";

// Polyfill THREE.Timer if it's not present natively in the core bundle
if (typeof (THREE as any).Timer === "undefined") {
  (THREE as any).Timer = class Timer {
    private _startTime: number;
    private _currentTime: number;
    private _previousTime: number;
    private _delta: number;
    private _elapsed: number;
    private _timescale: number;

    constructor() {
      this._startTime = performance.now();
      this._currentTime = 0;
      this._previousTime = 0;
      this._delta = 0;
      this._elapsed = 0;
      this._timescale = 1;
    }

    getDelta() {
      return this._delta / 1000;
    }

    getElapsed() {
      return this._elapsed / 1000;
    }

    getTimescale() {
      return this._timescale;
    }

    setTimescale(timescale: number) {
      this._timescale = timescale;
      return this;
    }

    reset() {
      this._currentTime = performance.now() - this._startTime;
      return this;
    }

    dispose() {}

    update(timestamp?: number) {
      this._previousTime = this._currentTime;
      this._currentTime = (timestamp !== undefined ? timestamp : performance.now()) - this._startTime;
      this._delta = (this._currentTime - this._previousTime) * this._timescale;
      this._elapsed += this._delta;
      return this;
    }
  };
}

interface ThreeScenePlayerProps {
  code: string;
  params: Record<string, number | boolean>;
  onError: (error: string) => void;
  topic?: string;
}

function decorateFloatingCard(card: HTMLDivElement) {
  // Guard against duplicate decoration
  if ((card as any).__isDecorated) return;
  (card as any).__isDecorated = true;

  const host = document.getElementById("threejs-canvas-host") as any;
  const activeTopic = host?.__activeTopic || "3D Concept";

  let isCardMinimized = false;
  let originalRawHTML = "";

  // Enforce absolute boundaries so the card never overflows the viewport width
  card.style.pointerEvents = "auto";
  card.style.maxWidth = "calc(100% - 24px)";
  card.style.boxSizing = "border-box";
  card.style.overflow = "hidden";
  card.style.whiteSpace = "normal";
  card.style.wordBreak = "break-word";
  card.style.wordWrap = "break-word";

  // Post-processor to ensure robust text-wrap and no overflows
  const postProcessHTML = (html: string) => {
    return html.replace(/style=(['"])(.*?)\1/g, (match, quote, styleContent) => {
      let cleanStyle = styleContent;
      
      // Override pointer-events: none inside inner layers so clicks reach our toggle button
      cleanStyle = cleanStyle.replace(/pointer-events\s*:\s*none/g, "pointer-events: auto");

      // Replace rigid min-width styles (e.g., min-width: 250px) with responsive boundaries
      cleanStyle = cleanStyle.replace(/min-width\s*:\s*[^'"]+?/g, (m) => {
        // Strip out absolute px min-width and enforce elastic bounding
        return "min-width: 0; max-width: 100%";
      });

      // Override non-wrapping sizes to prevent layout clipping
      cleanStyle = cleanStyle.replace(/width\s*:\s*(max-content|min-content|auto|[^;]*?px)/g, "width: 100%; max-width: 100%");
      
      // Inject essential text-wrapping, container, and responsive layout properties
      if (!cleanStyle.includes("box-sizing")) {
        cleanStyle += "; box-sizing: border-box";
      }
      if (!cleanStyle.includes("word-wrap") && !cleanStyle.includes("overflow-wrap")) {
        cleanStyle += "; word-wrap: break-word; overflow-wrap: break-word; word-break: break-word";
      }
      if (!cleanStyle.includes("white-space") || cleanStyle.includes("white-space: nowrap") || cleanStyle.includes("white-space:nowrap")) {
        cleanStyle = cleanStyle.replace(/white-space\s*:\s*nowrap/g, "white-space: normal");
        if (!cleanStyle.includes("white-space")) {
          cleanStyle += "; white-space: normal";
        }
      }
      if (!cleanStyle.includes("overflow")) {
        cleanStyle += "; overflow: hidden";
      }
      
      return `style=${quote}${cleanStyle}${quote}`;
    });
  };

  // Helper function to build expanded/collapsed content
  const buildFinalHTML = (rawHTML: string) => {
    if (isCardMinimized) {
      // Find a suitable title from the raw HTML patterns
      let title = activeTopic;
      const titleMatch = rawHTML.match(/font-weight:\s*700[^>]*>([^<]+)/i) || 
                         rawHTML.match(/<strong>([^<]+)<\/strong>/i) ||
                         rawHTML.match(/<b[^>]*>([^<]+)<\/b>/i) ||
                         rawHTML.match(/<div[^>]*font-weight:\s*700[^>]*>([^<]+)/i);
      
      if (titleMatch && titleMatch[1]) {
        title = titleMatch[1].replace(/<[^>]*>/g, "").trim();
      } else {
        // Fallback checks
        if (rawHTML.includes("Lorenz")) title = "Lorenz Attractor Core";
        else if (rawHTML.includes("Gravity")) title = "Solar Gravity Space";
        else if (rawHTML.includes("Superposition")) title = "Wave Superposition";
        else if (rawHTML.includes("Coulomb")) title = "Coulomb Electrostatics";
      }

      // Compact minimized capsule
      return `
        <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(15, 23, 42, 0.95); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 2.5px solid #8b5cf6; border-radius: 10px; padding: 6px 12px; font-family: 'Inter', system-ui, sans-serif; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.6); width: max-content; max-width: 100%; min-width: 180px; box-sizing: border-box; color: white; cursor: pointer; transition: all 0.25s ease;" onclick="this.parentElement.toggleMinimize()">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="color: #a855f7; font-size: 11px; transform: scale(1.1); filter: drop-shadow(0 0 4px rgba(168,85,247,0.4));">👁️</span>
            <span style="font-weight: 700; font-size: 9.5px; letter-spacing: 0.6px; text-transform: uppercase; color: #e9d5ff;">${title}</span>
          </div>
          <button type="button" aria-label="Expand Info Card" style="background: rgba(139, 92, 246, 0.25); border: 1px solid rgba(139, 92, 246, 0.6); color: #d8b4fe; cursor: pointer; font-family: monospace; font-size: 12px; font-weight: bold; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; border-radius: 4px; margin-left: 10px; transition: all 0.15s;" onmouseover="this.style.background='rgba(139, 92, 246, 0.45)';" onmouseout="this.style.background='rgba(139, 92, 246, 0.25)';" onclick="event.stopPropagation(); this.parentElement.parentElement.toggleMinimize()">
            +
          </button>
        </div>
      `;
    }

    // Process original content to guarantee text wraps and fits snugly
    const processedHTML = postProcessHTML(rawHTML);

    // Wrap the full, original content, but overlay an elegant, hoverable minimize button in the top-right corner.
    return `
      <div style="position: relative; width: 100%; max-width: 100%; height: 100%; overflow: hidden; white-space: normal; word-break: break-word; word-wrap: break-word; overflow-wrap: break-word; pointer-events: auto; box-sizing: border-box;">
        ${processedHTML}
        <!-- Minimize button -->
        <button type="button" 
          aria-label="Minimize Info Card"
          style="position: absolute; top: 8px; right: 8px; background: rgba(24, 24, 37, 0.95); border: 1.5px solid rgba(139, 92, 246, 0.7); color: #c084fc; cursor: pointer; font-family: x-monospace, monospace; font-size: 12px; font-weight: bold; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; border-radius: 6px; transition: all 0.2s ease; z-index: 9999; box-shadow: 0 2px 8px rgba(0,0,0,0.5); pointer-events: auto;" 
          onmouseover="this.style.background='#a855f7'; this.style.color='#ffffff'; this.style.borderColor='#a855f7';"
          onmouseout="this.style.background='rgba(24, 24, 37, 0.95)'; this.style.color='#c084fc'; this.style.borderColor='rgba(139, 92, 246, 0.7)';"
          onclick="event.stopPropagation(); this.parentElement.parentElement.toggleMinimize()">
          -
        </button>
      </div>
    `;
  };

  // Find the native innerHTML setter by walking up the prototype chain
  let nativeHTMLSetter: ((val: string) => void) | undefined;
  let p = Object.getPrototypeOf(card);
  while (p) {
    const desc = Object.getOwnPropertyDescriptor(p, "innerHTML");
    if (desc && desc.set) {
      nativeHTMLSetter = desc.set;
      break;
    }
    p = Object.getPrototypeOf(p);
  }

  // Fallback to Element prototype descriptor
  if (!nativeHTMLSetter) {
    nativeHTMLSetter = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML")?.set;
  }

  // Bind the toggle method to the card element
  (card as any).toggleMinimize = () => {
    isCardMinimized = !isCardMinimized;
    if (nativeHTMLSetter) {
      nativeHTMLSetter.call(card, buildFinalHTML(originalRawHTML));
    }
  };

  // Capture initial HTML and perform initial wrapping
  originalRawHTML = card.innerHTML;
  if (nativeHTMLSetter && originalRawHTML) {
    nativeHTMLSetter.call(card, buildFinalHTML(originalRawHTML));
  }

  // Intercept subsequent innerHTML changes
  Object.defineProperty(card, "innerHTML", {
    get() {
      return originalRawHTML;
    },
    set(val: string) {
      originalRawHTML = val;
      if (nativeHTMLSetter) {
        nativeHTMLSetter.call(card, buildFinalHTML(val));
      }
    },
    configurable: true,
    enumerable: true
  });
}

export default function ThreeScenePlayer({ code, params, onError, topic }: ThreeScenePlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const stageWrapperRef = useRef<HTMLDivElement>(null);
  const [evalError, setEvalError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const activeInstanceRef = useRef<{
    updateParams?: (newParams: Record<string, number | boolean>) => void;
    destroy?: () => void;
  } | null>(null);

  const toggleFullscreen = async () => {
    const wrapper = stageWrapperRef.current;
    if (!wrapper) return;
    try {
      if (!document.fullscreenElement) {
        await wrapper.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch (err) {
      console.error("Fullscreen toggle failed:", err);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  // Effect to clean up and re-mount when the code changes
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Set topic on the container
    (container as any).__activeTopic = topic || "3D Concept";

    // 1. Reset any previous error
    setEvalError(null);

    // 2. Clear out container completely to ensure no duplicate canvases
    container.innerHTML = "";

    // 3. Clean up the former running instance
    if (activeInstanceRef.current && typeof activeInstanceRef.current.destroy === "function") {
      try {
        activeInstanceRef.current.destroy();
      } catch (err) {
        console.warn("Error during simulation destruction:", err);
      }
    }
    activeInstanceRef.current = null;

    // 4. Set up a MutationObserver to safely intercept any info/equation cards and decorate them
    const isCardElement = (child: HTMLElement) => {
      if (!child || child.tagName !== "DIV") return false;
      const pos = child.style.position || "";
      const isAbsolute = pos === "absolute" || pos === "fixed";
      const top = child.style.top || "";
      const left = child.style.left || "";
      const transform = child.style.transform || "";
      const id = child.id || "";
      
      const matchesPosition = top === "12px" || left === "50%" || transform.includes("translateX(-50%)");
      const matchesID = id === "top-card" || id === "info-card";
      const matchesClass = child.classList.contains("info-card");
      
      return isAbsolute && (matchesPosition || matchesID || matchesClass);
    };

    // Scan initially created DOM elements (if any)
    container.querySelectorAll("div").forEach((child) => {
      if (isCardElement(child)) {
        decorateFloatingCard(child as HTMLDivElement);
      }
    });

    // Observe continuous changes dynamically (monitoring child additions and style mutations)
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "childList") {
          for (const node of mutation.addedNodes) {
            if (node instanceof HTMLElement && isCardElement(node)) {
              decorateFloatingCard(node as HTMLDivElement);
            }
          }
        } else if (mutation.type === "attributes") {
          const target = mutation.target;
          if (target instanceof HTMLElement && isCardElement(target)) {
            decorateFloatingCard(target as HTMLDivElement);
          }
        }
      }
    });

    observer.observe(container, { 
      childList: true, 
      subtree: true,
      attributes: true,
      attributeFilter: ["style", "class", "id"]
    });

    // Custom OrbitControls wrapper to decrease default rotate and zoom speed, and support permanent dynamic sensitivity multiplier
    const CustomOrbitControls = class extends OrbitControls {
      constructor(camera: any, jDom: any) {
        super(camera, jDom);
        // Explicitly reduce the default rotation and zoom speed by half
        this.rotateSpeed = 0.5;
        this.zoomSpeed = 0.6;

        // Apply starting sensitivity if present
        const startSens = params && params.interactionSensitivity !== undefined ? Number(params.interactionSensitivity) : 1.0;
        this.rotateSpeed = 0.5 * startSens;
        this.zoomSpeed = 0.6 * startSens;

        // Save reference for interactive updates
        if (container) {
          (container as any).__activeOrbitControls = this;
        }
      }
    };

    // 5. Try parsing and running the new Three.js script
    try {
      // Fix any instances or typos of 'opCardDiv' on-the-fly to ensure robust rendering of the Three.js canvases
      const correctedCode = (code || "").replace(/\bopCardDiv\b/g, "topCardDiv");

      // Create a proxy/wrapper for THREE to intercept WebGLRenderer, Scene, and Camera creation
      const THREEProxy = { ...THREE };

      const OriginalWebGLRenderer = THREE.WebGLRenderer;
      THREEProxy.WebGLRenderer = function (options?: any) {
        const renderer = new OriginalWebGLRenderer(options);
        if (container) {
          (container as any).__activeRenderer = renderer;
        }

        // Wrap setClearColor to force #0a2a4a
        const originalSetClearColor = renderer.setClearColor.bind(renderer);
        renderer.setClearColor = function (color: any, alpha?: number) {
          return originalSetClearColor(0x0a2a4a, 1);
        };

        // Call it initially
        renderer.setClearColor(0x0a2a4a, 1);
        return renderer;
      } as any;
      THREEProxy.WebGLRenderer.prototype = OriginalWebGLRenderer.prototype;

      const OriginalPerspectiveCamera = THREE.PerspectiveCamera;
      THREEProxy.PerspectiveCamera = function (fov?: number, aspect?: number, near?: number, far?: number) {
        const camera = new OriginalPerspectiveCamera(fov, aspect, near, far);
        if (container) {
          (container as any).__activeCamera = camera;
        }
        return camera;
      } as any;
      THREEProxy.PerspectiveCamera.prototype = OriginalPerspectiveCamera.prototype;

      const OriginalOrthographicCamera = THREE.OrthographicCamera;
      THREEProxy.OrthographicCamera = function (left?: number, right?: number, top?: number, bottom?: number, near?: number, far?: number) {
        const camera = new OriginalOrthographicCamera(left, right, top, bottom, near, far);
        if (container) {
          (container as any).__activeCamera = camera;
        }
        return camera;
      } as any;
      THREEProxy.OrthographicCamera.prototype = OriginalOrthographicCamera.prototype;

      const OriginalScene = THREE.Scene;
      THREEProxy.Scene = function () {
        const scene = new OriginalScene();
        let bg = new THREE.Color("#0a2a4a");
        Object.defineProperty(scene, "background", {
          get() {
            return bg;
          },
          set(value) {
            bg = new THREE.Color("#0a2a4a");
          },
          configurable: true,
          enumerable: true
        });
        return scene;
      } as any;
      THREEProxy.Scene.prototype = OriginalScene.prototype;

      // Dynamic compilation using secure 'new Function' pattern.
      // The generated code is expected to be a functional block. We evaluate it by returning a wrapper function.
      const runSimulation = new Function(
        "container",
        "THREE",
        "OrbitControls",
        "currentParams",
        `try {
          ${correctedCode}
        } catch (innerError) {
          throw innerError;
        }`
      );

      // Execute code and capture returned handle with direct native container
      const instance = runSimulation(container, THREEProxy, CustomOrbitControls, params);

      if (instance && (typeof instance.updateParams === "function" || typeof instance.destroy === "function")) {
        activeInstanceRef.current = instance;
      } else {
        console.warn("The generated Three.js code did not return a valid updateParams or destroy interface.");
      }
    } catch (err: any) {
      console.warn("Could not load dynamic Three.js simulation script, falling to safe mode:", err);
      const msg = err?.message || String(err);
      setEvalError(msg);
      onError(msg);
    }

    // Cleanup on unmount or subsequent code change
    return () => {
      observer.disconnect();
      if (container) {
        delete (container as any).__activeOrbitControls;
      }
      if (activeInstanceRef.current && typeof activeInstanceRef.current.destroy === "function") {
        try {
          activeInstanceRef.current.destroy();
        } catch (err) {
          console.warn("Error calling destroy on dynamic Three.js script:", err);
        }
      }
      activeInstanceRef.current = null;
    };
  }, [code]);

  // Effect to handle live param updates from sliders/toggles without refreshing the canvas
  useEffect(() => {
    if (activeInstanceRef.current && typeof activeInstanceRef.current.updateParams === "function") {
      try {
        activeInstanceRef.current.updateParams(params);
      } catch (err) {
        console.warn("Error sending parameter update to dynamic Three.js simulation:", err);
      }
    }

    // Adapt OrbitControls dynamically based on the interactionSensitivity slider
    const container = containerRef.current;
    if (container && (container as any).__activeOrbitControls) {
      try {
        const sens = params && params.interactionSensitivity !== undefined ? Number(params.interactionSensitivity) : 1.0;
        const controls = (container as any).__activeOrbitControls;
        controls.rotateSpeed = 0.5 * sens;
        controls.zoomSpeed = 0.6 * sens;
      } catch (err) {
        console.warn("Error updating dynamic orbit controls speed:", err);
      }
    }
  }, [params]);

  // Effect to observe container dimensions and update renderer/camera sizing on change
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width === 0 || height === 0) continue;

        // 1. Update cached active renderer if present
        const renderer = (container as any).__activeRenderer;
        if (renderer) {
          try {
            renderer.setSize(width, height);
          } catch (e) {
            console.warn("Resize error on renderer:", e);
          }
        }

        // 2. Update cached active camera if present
        const camera = (container as any).__activeCamera;
        if (camera) {
          try {
            if (camera.isPerspectiveCamera) {
              camera.aspect = width / height;
              camera.updateProjectionMatrix();
            } else if (camera.isOrthographicCamera) {
              const aspect = width / height;
              const frustumHeight = (camera.top - camera.bottom) || 10;
              camera.left = -frustumHeight * aspect / 2;
              camera.right = frustumHeight * aspect / 2;
              camera.updateProjectionMatrix();
            }
          } catch (e) {
            console.warn("Resize error on camera:", e);
          }
        }

        // 3. Dispatch global resize event to let other internal event listeners adjust
        window.dispatchEvent(new Event("resize"));
      }
    });

    resizeObserver.observe(container);
    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <div ref={stageWrapperRef} className="relative w-full h-[320px] sm:h-[400px] md:h-[480px] lg:h-[520px] bg-gradient-to-b from-[#0a2a4a] to-[#041424] rounded-xl overflow-hidden border border-neutral-800">
      {/* Container where the WebGL Canvas is appended */}
      <div id="threejs-canvas-host" ref={containerRef} className="w-full h-full absolute inset-0" />

      {/* Fullscreen Toggle Button */}
      <button
        onClick={toggleFullscreen}
        className="absolute right-4 top-4 p-2.5 bg-black/75 hover:bg-neutral-900 border border-neutral-800 hover:border-neutral-700 rounded-lg text-neutral-300 hover:text-white transition-all duration-200 shadow-md backdrop-blur-sm z-30 flex items-center justify-center cursor-pointer"
        title={isFullscreen ? "Exit Fullscreen" : "Fullscreen Mode"}
      >
        {isFullscreen ? <Minimize2 className="w-4.5 h-4.5" /> : <Maximize2 className="w-4.5 h-4.5" />}
      </button>

      {/* Floating Error overlay */}
      {evalError && (
        <div className="absolute inset-x-4 top-16 p-4 bg-red-950/90 border border-red-500/50 rounded-lg text-red-200 text-sm font-mono backdrop-blur-md shadow-lg z-10 overflow-y-auto max-h-[250px]">
          <div className="font-semibold text-red-400 mb-1 flex items-center gap-2">
            <span>⚠️ Visual Render Compile Error</span>
          </div>
          <p className="whitespace-pre-wrap">{evalError}</p>
          <div className="mt-2 text-xs text-neutral-400">
            Note: This can sometimes happen when the AI outputs complex experimental logic. Try pressing "Re-generate" or adjusting parameters!
          </div>
        </div>
      )}

      {/* UI Interaction Cue */}
      {!evalError && (
        <div className="absolute right-4 bottom-4 px-3 py-1 bg-black/70 border border-neutral-800 rounded-full text-xs text-neutral-300 font-medium select-none pointer-events-none backdrop-blur-sm shadow-sm flex items-center gap-1.5 z-10 transition-opacity duration-300">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Interactive 3D Stage (Drag/Orbit/Zoom)
        </div>
      )}
    </div>
  );
}
