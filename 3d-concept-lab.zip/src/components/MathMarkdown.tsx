import React from "react";
import ReactMarkdown from "react-markdown";
import katex from "katex";

interface MathMarkdownProps {
  content: string;
}

/**
 * Searches for $...$ and $$...$$ inside a text element,
 * and compiles them to KaTeX React components dynamically. Also pre-processes plain math representations.
 */
export function renderMathInText(text: string): React.ReactNode {
  if (!text || typeof text !== "string") return text;

  let processedText = text;

  // Standardize backslash delimiters \[ ... \] and \( ... \)
  processedText = processedText.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => `$$${math}$$`);
  processedText = processedText.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => `$${math}$`);

  const parts: React.ReactNode[] = [];
  let currentIdx = 0;

  while (currentIdx < processedText.length) {
    const nextDouble = processedText.indexOf("$$", currentIdx);
    const nextSingle = processedText.indexOf("$", currentIdx);

    if (nextDouble === -1 && nextSingle === -1) {
      parts.push(processedText.slice(currentIdx));
      break;
    }

    if (nextDouble !== -1 && (nextSingle === -1 || nextDouble <= nextSingle)) {
      if (nextDouble > currentIdx) {
        parts.push(processedText.slice(currentIdx, nextDouble));
      }
      const closingDouble = processedText.indexOf("$$", nextDouble + 2);
      if (closingDouble === -1) {
        parts.push(processedText.slice(nextDouble));
        break;
      } else {
        const math = processedText.slice(nextDouble + 2, closingDouble);
        try {
          const html = katex.renderToString(math.trim(), {
            displayMode: true,
            throwOnError: false,
          });
          parts.push(
            <span
              key={`math-block-${nextDouble}`}
              className="block my-4 overflow-x-auto py-3 px-4 bg-neutral-900/50 border border-neutral-800 rounded-xl text-center shadow-md font-sans text-neutral-100 select-all scale-[1.01] transition-transform duration-150"
              style={{ minHeight: "1.5em" }}
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        } catch (e) {
          parts.push(<pre key={`err-${nextDouble}`} className="text-red-400 p-2 text-xs font-mono">{math}</pre>);
        }
        currentIdx = closingDouble + 2;
      }
    } else {
      if (nextSingle > currentIdx) {
        parts.push(processedText.slice(currentIdx, nextSingle));
      }
      const closingSingle = processedText.indexOf("$", nextSingle + 1);
      if (closingSingle === -1) {
        parts.push(processedText.slice(nextSingle));
        break;
      } else {
        const math = processedText.slice(nextSingle + 1, closingSingle);
        try {
          const html = katex.renderToString(math.trim(), {
            displayMode: false,
            throwOnError: false,
          });
          parts.push(
            <span
              key={`math-inline-${nextSingle}`}
              className="inline-block px-1 font-sans text-indigo-200 select-all"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          );
        } catch (e) {
          parts.push(<code key={`err-${nextSingle}`} className="text-red-400 font-mono text-xs">{math}</code>);
        }
        currentIdx = closingSingle + 1;
      }
    }
  }

  return parts;
}

/**
 * Recursively walks the React node tree to process text elements for KaTeX.
 */
export function processNode(node: React.ReactNode): React.ReactNode {
  if (node === null || node === undefined) return node;
  if (typeof node === "string") {
    return renderMathInText(node);
  }
  if (typeof node === "number" || typeof node === "boolean") {
    return node;
  }
  if (Array.isArray(node)) {
    return node.map((child, i) => <React.Fragment key={i}>{processNode(child)}</React.Fragment>);
  }
  if (React.isValidElement(node)) {
    const props = node.props as any;
    if (props && props.children) {
      return React.cloneElement(node, {
        ...(node.props as any),
        children: processNode(props.children),
      } as any);
    }
  }
  return node;
}

const customMathComponents = {
  p: ({ children }: any) => <div className="mb-3.5 leading-relaxed text-neutral-300">{processNode(children)}</div>,
  li: ({ children }: any) => <li className="mb-2 leading-relaxed text-neutral-300 list-disc ml-5">{processNode(children)}</li>,
  h1: ({ children }: any) => <h1 className="text-xl font-display font-bold mt-5 mb-2.5 text-neutral-100 border-b border-neutral-900 pb-1">{processNode(children)}</h1>,
  h2: ({ children }: any) => <h2 className="text-lg font-display font-bold mt-4 mb-2 text-neutral-100 border-b border-neutral-900/40 pb-0.5">{processNode(children)}</h2>,
  h3: ({ children }: any) => <h3 className="text-base font-display font-semibold mt-3.5 mb-1.5 text-neutral-200">{processNode(children)}</h3>,
  h4: ({ children }: any) => <h4 className="text-sm font-display font-semibold mt-2.5 mb-1 text-neutral-200">{processNode(children)}</h4>,
  span: ({ children }: any) => <span>{processNode(children)}</span>,
  strong: ({ children }: any) => <strong className="font-semibold text-indigo-300">{processNode(children)}</strong>,
  em: ({ children }: any) => <em className="italic text-zinc-400">{processNode(children)}</em>,
  td: ({ children }: any) => <td className="p-2 border border-neutral-900 text-neutral-300">{processNode(children)}</td>,
  th: ({ children }: any) => <th className="p-2 border border-neutral-900 font-semibold bg-neutral-900/40 text-neutral-200 text-left">{processNode(children)}</th>,
};

export const MathMarkdown: React.FC<MathMarkdownProps> = ({ content }) => {
  return (
    <div className="math-markdown prose prose-invert select-text">
      <ReactMarkdown components={customMathComponents as any}>{content}</ReactMarkdown>
    </div>
  );
};
