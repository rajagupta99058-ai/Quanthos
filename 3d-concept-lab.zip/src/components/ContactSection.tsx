import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Send, Check, MessageSquare, ShieldAlert, RefreshCw } from "lucide-react";

interface ContactSectionProps {
  userEmail?: string;
}

export function ContactSection({ userEmail = "" }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: userEmail,
    subject: "General Feedback",
    message: "",
  });

  React.useEffect(() => {
    if (userEmail) {
      setFormData(prev => ({ ...prev, email: userEmail }));
    }
  }, [userEmail]);

  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!formData.name.trim()) {
      setErrorMessage("Please enter your name.");
      setStatus("error");
      return;
    }
    if (!formData.email.trim() || !formData.email.includes("@")) {
      setErrorMessage("Please enter a valid email address.");
      setStatus("error");
      return;
    }
    if (!formData.message.trim()) {
      setErrorMessage("Please enter your message.");
      setStatus("error");
      return;
    }

    setStatus("submitting");

    try {
      // Sending actual email using FormSubmit AJAX endpoint to user's real email
      const response = await fetch("https://formsubmit.co/ajax/rajak788649@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          _subject: `New Quanthos Support Message: ${formData.subject}`,
          message: formData.message,
        })
      });

      if (response.ok) {
        setStatus("success");
        setFormData({
          name: "",
          email: "",
          subject: "General Feedback",
          message: "",
        });
      } else {
        throw new Error("Failed to deliver message via contact gateway.");
      }
    } catch (err: any) {
      console.error("Contact form error:", err);
      setErrorMessage("Could not send message. Please try again or email directly at rajak788649@gmail.com.");
      setStatus("error");
    }
  };

  return (
    <section id="contact" className="w-full max-w-3xl mx-auto px-6 py-12 relative z-10">
      
      {/* Decorative gradient accents */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full bg-cyan-500/5 blur-[120px] pointer-events-none" />

      <div className="flex flex-col gap-8 text-center">
        {/* Header Section */}
        <div className="flex flex-col items-center gap-2">
          <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase font-bold flex items-center gap-1.5 px-2.5 py-1 bg-cyan-950/30 border border-cyan-900/30 rounded-full">
            <MessageSquare className="w-3 h-3 text-cyan-400" />
            Contact & Support
          </span>
          <h2 className="text-3xl font-black font-display text-white tracking-tight leading-tight mt-2">
            Get in Touch
          </h2>
          <p className="text-xs text-neutral-400 leading-relaxed max-w-md mt-1">
            Have any questions, feedback, or suggestions? Fill out the form below to send a message directly to Rajak.
          </p>
        </div>

        {/* Contact Form Card */}
        <div className="bg-neutral-950/40 border border-neutral-900/80 rounded-2xl p-6 md:p-8 relative overflow-hidden backdrop-blur-sm shadow-2xl text-left">
          <AnimatePresence mode="wait">
            {status === "success" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col items-center justify-center text-center py-8 space-y-4"
              >
                <div className="w-12 h-12 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shadow-inner">
                  <Check className="w-6 h-6" />
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">Message Sent Successfully!</h3>
                  <p className="text-[11px] text-neutral-400 max-w-sm leading-relaxed font-mono">
                    Your message is on its way. Rajak will review it and get back to you as soon as possible.
                  </p>
                  <p className="text-[10px] text-neutral-500 leading-relaxed max-w-xs mx-auto pt-2 font-mono">
                    (Note: If this is the first submission, please check your inbox to click FormSubmit's verification email to activate form forwarding).
                  </p>
                </div>
                <button
                  onClick={() => setStatus("idle")}
                  className="mt-4 px-4 py-1.5 bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-400 text-[10px] font-mono uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                >
                  Send another message
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onSubmit={handleSubmit}
                className="space-y-5"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold">Your Name</label>
                    <input
                      type="text"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        if (status === "error") setStatus("idle");
                      }}
                      className="w-full bg-neutral-950/60 border border-neutral-900 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-cyan-500/40 transition-colors font-mono"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold">Email Address</label>
                    <input
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      readOnly={!!userEmail}
                      onChange={(e) => {
                        if (!userEmail) {
                          setFormData({ ...formData, email: e.target.value });
                          if (status === "error") setStatus("idle");
                        }
                      }}
                      className={`w-full bg-neutral-950/60 border border-neutral-900 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-cyan-500/40 transition-colors font-mono ${
                        userEmail ? "cursor-not-allowed opacity-75 text-neutral-400" : ""
                      }`}
                    />
                  </div>
                </div>

                {/* Subject Dropdown */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold">Subject</label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full bg-neutral-950/60 border border-neutral-900 rounded-xl px-3 py-2.5 text-xs text-neutral-350 focus:outline-none focus:border-cyan-500/40 transition-colors font-mono appearance-none cursor-pointer"
                  >
                    <option value="General Feedback" className="bg-[#050508] text-neutral-300">General Feedback & Suggestions</option>
                    <option value="Bug / System Issue" className="bg-[#050508] text-neutral-300">Bug / System Issue</option>
                    <option value="Custom Simulation Request" className="bg-[#050508] text-neutral-300">Custom Simulation Request</option>
                    <option value="Inquiry" className="bg-[#050508] text-neutral-300">Other Inquiries</option>
                  </select>
                </div>

                {/* Message text area */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold">Message Description</label>
                  <textarea
                    rows={5}
                    placeholder="Provide details about your question, feedback, or request..."
                    value={formData.message}
                    onChange={(e) => {
                      setFormData({ ...formData, message: e.target.value });
                      if (status === "error") setStatus("idle");
                    }}
                    className="w-full bg-neutral-950/60 border border-neutral-900 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-cyan-500/40 transition-colors font-mono resize-none leading-relaxed"
                  />
                </div>

                {/* Direct Mail info */}
                <div className="text-[10px] font-mono text-neutral-500 flex items-center gap-1.5">
                  <Mail className="w-3 h-3 text-cyan-400" />
                  <span>Direct contact: <a href="mailto:rajak788649@gmail.com" className="text-cyan-400 hover:underline">rajak788649@gmail.com</a></span>
                </div>

                {/* Error handling */}
                <AnimatePresence>
                  {status === "error" && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="flex items-center gap-2 text-[10px] font-mono text-rose-400 bg-rose-950/20 border border-rose-900/30 p-2.5 rounded-lg text-left"
                    >
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>{errorMessage}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Action button */}
                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="w-full py-3 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 text-xs font-mono font-bold uppercase tracking-wider rounded-xl shadow-lg shadow-cyan-950/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  {status === "submitting" ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 text-neutral-950 animate-spin" />
                      <span>Sending Message...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5 text-neutral-950" />
                      <span>Send Message</span>
                    </>
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
