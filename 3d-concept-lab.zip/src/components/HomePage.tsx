import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { getAuth } from "firebase/auth";
import { 
  Sparkles, 
  ArrowRight, 
  Lightbulb,
  Cpu,
  User,
  GraduationCap,
  Calendar,
  Atom,
  Briefcase,
  Clock,
  Download,
  Trash2,
  Check,
  Compass,
  Activity,
  Layers,
  ChevronRight,
  Sliders,
  RotateCcw,
  Zap,
  X,
  Menu,
  FlaskConical,
  Globe,
  Mail,
  Send,
  MessageSquare
} from "lucide-react";
import { SavedHistoryItem, UserProfile } from "../types";
import { QuanthosLogo } from "./QuanthosLogo";

interface HomePageProps {
  email: string;
  history: SavedHistoryItem[];
  onSearch: (query: string) => void;
  onLoadPreset: (presetKey: string) => void;
  onNavigateToLab: () => void;
  onNavigateToContact: () => void;
  onClearHistory: () => void;
  onSignOut: () => void;
}

const ACADEMIC_ROLES = [
  "Quantum Engineer",
  "Astro-Physicist",
  "Undergraduate Student",
  "Graduate Researcher",
  "Academic Professor",
  "Space Hobbyist",
  "Data Scientist",
  "STEM Educator",
  "General Science Enthusiast"
];

const RESEARCH_FOCUSES = [
  "Chaos Theory & Dynamic Systems",
  "Celestial Mechanics & Keplerian Gravity",
  "Wave Optics & Physical Wave Mechanics",
  "Hydrostatics & Transverse Stability",
  "Thermodynamics & Statistical Mechanics",
  "Quantum Mechanics & Particle Interactions",
  "Electromagnetism & Coulomb Forces",
  "None / Universal STEM Scholar"
];

const AVATAR_EMOJIS = ["🧬", "⚛️", "🪐", "🌌", "🧪", "📡", "🛸", "🧠", "⚓", "📐", "🚀"];
const AVATAR_COLORS = [
  "from-slate-700 to-slate-800",
  "from-emerald-600 to-emerald-800",
  "from-amber-500 to-amber-700",
  "from-slate-800 to-slate-900"
];

// Interactive Topographic Grid wave background for the Hero section
export function HeroWaveBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    let mouseX = width / 2;
    let mouseY = height / 2;
    let targetMouseX = mouseX;
    let targetMouseY = mouseY;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      targetMouseX = e.clientX - rect.left;
      targetMouseY = e.clientY - rect.top;
    };
    window.addEventListener("mousemove", handleMouseMove);

    let time = 0;

    const render = () => {
      time += 0.004;

      // Smooth mouse tracking
      mouseX += (targetMouseX - mouseX) * 0.1;
      mouseY += (targetMouseY - mouseY) * 0.1;

      ctx.clearRect(0, 0, width, height);

      // Create flowing mesh terrain wave effect
      const waveCount = 16;
      const pointsPerWave = 45;

      for (let i = 0; i < waveCount; i++) {
        ctx.beginPath();
        const yOffset = height * 0.1 + (i / waveCount) * height * 0.85;
        const speedMultiplier = 1.0 - i * 0.015;

        for (let j = 0; j <= pointsPerWave; j++) {
          const x = (j / pointsPerWave) * width;
          
          // Double sine-cosine wave formula
          const frequency1 = 0.0025 + i * 0.0001;
          const frequency2 = 0.007 - i * 0.0001;
          const baseSin = Math.sin(x * frequency1 + time * speedMultiplier * 1.4);
          const secondaryCos = Math.cos(x * frequency2 - time * speedMultiplier * 1.1);
          
          let y = yOffset + (baseSin * 16) + (secondaryCos * 10);

          // Apply local gravity/ripple warp on hover
          const distToMouseX = x - mouseX;
          const distToMouseY = yOffset - mouseY;
          const distance = Math.sqrt(distToMouseX * distToMouseX + distToMouseY * distToMouseY);
          
          if (distance < 160) {
            const force = (1.0 - distance / 160) * 32;
            y += Math.sin(distance * 0.06 - time * 6) * force;
          }

          if (j === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }

        // Beautiful cyan transparency gradient representing Quanthos contours
        const alpha = 0.04 + (i / waveCount) * 0.16;
        ctx.strokeStyle = `rgba(34, 211, 238, ${alpha})`;
        ctx.lineWidth = 1.15;
        ctx.stroke();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
    />
  );
}

// Module 1: Physics concentrical wave interference engine
export function PhysicsWaveVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [sourcesMode, setSourcesMode] = useState<"single" | "dual" | "outOfPhase">("dual");
  const [frequency, setFrequency] = useState(1.0);
  const [density, setDensity] = useState(1.0);

  const freqRef = useRef(frequency);
  const modeRef = useRef(sourcesMode);
  const densityRef = useRef(density);

  useEffect(() => { freqRef.current = frequency; }, [frequency]);
  useEffect(() => { modeRef.current = sourcesMode; }, [sourcesMode]);
  useEffect(() => { densityRef.current = density; }, [density]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    let mouseX = width * 0.65;
    let mouseY = height * 0.5;
    let targetMouseX = mouseX;
    let targetMouseY = mouseY;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      targetMouseX = e.clientX - rect.left;
      targetMouseY = e.clientY - rect.top;
    };
    canvas.addEventListener("mousemove", handleMouseMove);

    let time = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      
      // Access current state via refs to avoid stale closures in render loops
      const freqVal = freqRef.current;
      const modeVal = modeRef.current;
      const densVal = densityRef.current;

      time += 0.15 * freqVal;

      // Smooth mouse coordinate tracking
      mouseX += (targetMouseX - mouseX) * 0.1;
      mouseY += (targetMouseY - mouseY) * 0.1;

      const sAx = width * 0.35;
      const sAy = height * 0.5;
      const sBx = mouseX;
      const sBy = mouseY;

      // Holographic coordinate grid
      ctx.strokeStyle = "rgba(34, 211, 238, 0.015)";
      ctx.lineWidth = 1;
      const gridSize = 16;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      const waveCount = 8;
      
      // Source A wave propagation (cyan)
      for (let i = 0; i < waveCount; i++) {
        const r = ((time + i * 20 * densVal) % 160);
        const alpha = Math.max(0, 1.0 - r / 160) * 0.45;
        
        ctx.beginPath();
        ctx.arc(sAx, sAy, r, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(6, 182, 212, ${alpha})`;
        ctx.lineWidth = 1.6;
        ctx.stroke();
      }

      // Source B wave propagation (violet or red depending on phase)
      if (modeVal !== "single") {
        const isOutOfPhase = modeVal === "outOfPhase";
        for (let i = 0; i < waveCount; i++) {
          const phaseShift = isOutOfPhase ? 10 * densVal : 0;
          const r = ((time * 0.85 + i * 20 * densVal + phaseShift) % 160);
          const alpha = Math.max(0, 1.0 - r / 160) * 0.45;
          
          ctx.beginPath();
          ctx.arc(sBx, sBy, r, 0, Math.PI * 2);
          ctx.strokeStyle = isOutOfPhase 
            ? `rgba(244, 63, 94, ${alpha})` // Rose/Red for anti-symmetric
            : `rgba(139, 92, 246, ${alpha})`; // Violet for default
          ctx.lineWidth = 1.6;
          ctx.stroke();
        }
      }

      // Source Cores
      ctx.shadowBlur = 8;
      ctx.shadowColor = "#22d3ee";
      ctx.beginPath();
      ctx.arc(sAx, sAy, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#22d3ee";
      ctx.fill();

      if (modeVal !== "single") {
        ctx.shadowColor = modeVal === "outOfPhase" ? "#f43f5e" : "#a78bfa";
        ctx.beginPath();
        ctx.arc(sBx, sBy, 5, 0, Math.PI * 2);
        ctx.fillStyle = modeVal === "outOfPhase" ? "#f43f5e" : "#a78bfa";
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      // Labels
      ctx.fillStyle = "rgba(148, 163, 184, 0.4)";
      ctx.font = "8px monospace";
      ctx.fillText("NODE_A: SOURCE", sAx - 38, sAy - 10);
      if (modeVal !== "single") {
        ctx.fillText(modeVal === "outOfPhase" ? "NODE_B: ANTI-PHASE" : "NODE_B: CO-PHASE", sBx - 45, sBy - 10);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      canvas.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-[#050508] border border-neutral-900 rounded-2xl overflow-hidden shadow-inner flex flex-col group">
      
      {/* Canvas Header/Status */}
      <div className="relative flex-1 min-h-[170px] bg-neutral-950/20">
        <canvas ref={canvasRef} className="w-full h-full block" />
        <div className="absolute top-3 left-4 flex items-center gap-1.5 px-2 py-0.5 bg-neutral-950/90 border border-neutral-900 rounded text-[9px] text-cyan-400 font-mono uppercase tracking-wider">
          <Activity className="w-2.5 h-2.5 animate-pulse text-cyan-400" />
          Interactive Wave Laboratory
        </div>
      </div>

      {/* Control Deck */}
      <div className="bg-neutral-950/95 border-t border-neutral-900 p-4 space-y-3.5 relative z-10">
        
        {/* Row 1: Source Toggle */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold flex items-center justify-between">
            <span>Interference Setup</span>
            <span className="text-cyan-400 font-bold">{sourcesMode.toUpperCase()}</span>
          </label>
          <div className="grid grid-cols-3 gap-1 bg-neutral-900/60 p-0.5 border border-neutral-850 rounded-lg">
            {(["single", "dual", "outOfPhase"] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setSourcesMode(mode)}
                className={`py-1 text-[8px] font-mono rounded uppercase tracking-wider transition-colors cursor-pointer ${
                  sourcesMode === mode
                    ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold"
                    : "text-neutral-500 hover:text-neutral-300"
                }`}
              >
                {mode === "single" ? "Single Node" : mode === "dual" ? "Co-Phase" : "Anti-Phase"}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2: Sliders */}
        <div className="grid grid-cols-2 gap-4">
          {/* Frequency Slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Oscillation Rate</span>
              <span className="text-cyan-400/80 font-bold">{frequency.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.1"
              value={frequency}
              onChange={(e) => setFrequency(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>

          {/* Density Slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Medium Dispersion</span>
              <span className="text-cyan-400/80 font-bold">{density.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.6"
              step="0.1"
              value={density}
              onChange={(e) => setDensity(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>
        </div>

      </div>
    </div>
  );
}

// Module 2: Mathematics Fourier Circle series drawing engine
export function MathFourierVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [waveType, setWaveType] = useState<"square" | "sawtooth" | "triangle">("square");
  const [harmonics, setHarmonics] = useState(4);
  const [speed, setSpeed] = useState(1.0);

  const waveTypeRef = useRef(waveType);
  const harmonicsRef = useRef(harmonics);
  const speedRef = useRef(speed);

  useEffect(() => { waveTypeRef.current = waveType; }, [waveType]);
  useEffect(() => { harmonicsRef.current = harmonics; }, [harmonics]);
  useEffect(() => { speedRef.current = speed; }, [speed]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    let time = 0;
    let wavePoints: number[] = [];
    const maxWavePoints = 140;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const typeVal = waveTypeRef.current;
      const harmVal = harmonicsRef.current;
      const speedVal = speedRef.current;

      time += 0.028 * speedVal;

      // Graph backdrop grid
      ctx.strokeStyle = "rgba(165, 180, 252, 0.015)";
      ctx.lineWidth = 1;
      const gridSize = 20;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Origin of rotating circles
      const cx = width * 0.24;
      const cy = height * 0.5;

      let x = cx;
      let y = cy;

      // Dynamically calculate Fourier series coefficients
      const baseRadius = 40;
      const circles: { radius: number; speed: number }[] = [];

      for (let i = 1; i <= harmVal; i++) {
        if (typeVal === "square") {
          // Odd harmonics: 1, 3, 5, 7, ...
          const k = 2 * i - 1;
          const radius = baseRadius * (4 / Math.PI) * (1 / k);
          circles.push({ radius, speed: k });
        } else if (typeVal === "sawtooth") {
          // All harmonics: 1, 2, 3, 4, ...
          const radius = baseRadius * (2 / Math.PI) * (1 / i) * (i % 2 === 0 ? -1 : 1);
          circles.push({ radius, speed: i });
        } else if (typeVal === "triangle") {
          // Odd harmonics with squared decay: 1, 9, 25, 49...
          const k = 2 * i - 1;
          const sign = (i % 2 === 0) ? -1 : 1;
          const radius = baseRadius * (8 / (Math.PI * Math.PI)) * (sign / (k * k));
          circles.push({ radius, speed: k });
        }
      }

      circles.forEach((circle, index) => {
        const prevX = x;
        const prevY = y;

        const angle = time * circle.speed;
        x += Math.cos(angle) * circle.radius;
        y += Math.sin(angle) * circle.radius;

        // Radial Circle outline
        ctx.beginPath();
        ctx.arc(prevX, prevY, Math.abs(circle.radius), 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(139, 92, 246, ${0.18 - index * 0.025})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Vector arrow linkage
        ctx.beginPath();
        ctx.moveTo(prevX, prevY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = "rgba(167, 139, 250, 0.4)";
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // Node joint dot
        ctx.beginPath();
        ctx.arc(x, y, 2.2, 0, Math.PI * 2);
        ctx.fillStyle = "#c084fc";
        ctx.fill();
      });

      wavePoints.unshift(y);
      if (wavePoints.length > maxWavePoints) {
        wavePoints.pop();
      }

      // Tracing auxiliary guideline
      const traceStartX = width * 0.45;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(traceStartX, y);
      ctx.strokeStyle = "rgba(244, 63, 94, 0.15)";
      ctx.setLineDash([2, 2]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Compiled Harmonic Synthesized Wave curve
      ctx.beginPath();
      for (let i = 0; i < wavePoints.length; i++) {
        const wx = traceStartX + i * 2.2;
        if (wx > width - 15) break;
        if (i === 0) ctx.moveTo(wx, wavePoints[i]);
        else ctx.lineTo(wx, wavePoints[i]);
      }
      ctx.strokeStyle = "rgba(139, 92, 246, 0.85)";
      ctx.lineWidth = 2.0;
      ctx.shadowColor = "rgba(139, 92, 246, 0.3)";
      ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.shadowBlur = 0;

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-[#050508] border border-neutral-900 rounded-2xl overflow-hidden shadow-inner flex flex-col group">
      
      {/* Canvas Header/Status */}
      <div className="relative flex-1 min-h-[170px] bg-neutral-950/20">
        <canvas ref={canvasRef} className="w-full h-full block" />
        <div className="absolute top-3 left-4 flex items-center gap-1.5 px-2 py-0.5 bg-neutral-950/90 border border-neutral-900 rounded text-[9px] text-violet-400 font-mono uppercase tracking-wider">
          <Activity className="w-2.5 h-2.5 animate-pulse text-violet-400" />
          Harmonic Wave Equation Synthesizer
        </div>
      </div>

      {/* Control Deck */}
      <div className="bg-neutral-950/95 border-t border-neutral-900 p-4 space-y-3.5 relative z-10">
        
        {/* Row 1: Function Wave Type Toggle */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold flex items-center justify-between">
            <span>Wave Series Function</span>
            <span className="text-violet-400 font-bold">{waveType.toUpperCase()}</span>
          </label>
          <div className="grid grid-cols-3 gap-1 bg-neutral-900/60 p-0.5 border border-neutral-850 rounded-lg">
            {(["square", "sawtooth", "triangle"] as const).map((type) => (
              <button
                key={type}
                onClick={() => setWaveType(type)}
                className={`py-1 text-[8px] font-mono rounded uppercase tracking-wider transition-colors cursor-pointer ${
                  waveType === type
                    ? "bg-violet-500/10 text-violet-400 border border-violet-500/20 font-bold"
                    : "text-neutral-500 hover:text-neutral-300"
                }`}
              >
                {type === "square" ? "Square" : type === "sawtooth" ? "Sawtooth" : "Triangle"}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2: Sliders */}
        <div className="grid grid-cols-2 gap-4">
          {/* Harmonics quantity */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Harmonic Terms</span>
              <span className="text-violet-400/80 font-bold">{harmonics} N</span>
            </div>
            <input
              type="range"
              min="1"
              max="8"
              step="1"
              value={harmonics}
              onChange={(e) => setHarmonics(parseInt(e.target.value))}
              className="w-full accent-violet-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>

          {/* Speed slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Base Frequency</span>
              <span className="text-violet-400/80 font-bold">{speed.toFixed(1)}Hz</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.1"
              value={speed}
              onChange={(e) => setSpeed(parseFloat(e.target.value))}
              className="w-full accent-violet-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>
        </div>

      </div>
    </div>
  );
}

// Module 3: Chemistry molecular dynamics canvas
export function ChemistryBondVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [temperature, setTemperature] = useState(1.0);
  const [bondDistance, setBondDistance] = useState(72);
  const [mixture, setMixture] = useState<"soup" | "water" | "co2">("soup");

  const tempRef = useRef(temperature);
  const bondDistRef = useRef(bondDistance);
  const mixRef = useRef(mixture);

  useEffect(() => { tempRef.current = temperature; }, [temperature]);
  useEffect(() => { bondDistRef.current = bondDistance; }, [bondDistance]);
  useEffect(() => { mixRef.current = mixture; }, [mixture]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", handleResize);

    interface Atom {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      color: string;
      label: string;
    }

    const atoms: Atom[] = [];
    const elementsPool = [
      { color: "#10b981", label: "C", radius: 8 }, 
      { color: "#ef4444", label: "O", radius: 7 }, 
      { color: "#3b82f6", label: "H", radius: 5 }, 
      { color: "#f59e0b", label: "N", radius: 8 }  
    ];

    // Seed 28 atoms
    for (let i = 0; i < 28; i++) {
      const el = elementsPool[Math.floor(Math.random() * elementsPool.length)];
      atoms.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 1.5,
        vy: (Math.random() - 0.5) * 1.5,
        radius: el.radius,
        color: el.color,
        label: el.label
      });
    }

    let mouseX = -1000;
    let mouseY = -1000;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    };
    const handleMouseLeave = () => {
      mouseX = -1000;
      mouseY = -1000;
    };
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const tempVal = tempRef.current;
      const bondDistVal = bondDistRef.current;
      const mixVal = mixRef.current;

      // Filter active atoms depending on selected compound mixture
      const activeAtoms = atoms.filter((atom) => {
        if (mixVal === "water") {
          return atom.label === "H" || atom.label === "O";
        }
        if (mixVal === "co2") {
          return atom.label === "C" || atom.label === "O";
        }
        return true; // "soup" mixture includes everything
      });

      // Draw covalent bonds between compatible nearby atoms
      for (let i = 0; i < activeAtoms.length; i++) {
        for (let j = i + 1; j < activeAtoms.length; j++) {
          const dx = activeAtoms[i].x - activeAtoms[j].x;
          const dy = activeAtoms[i].y - activeAtoms[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < bondDistVal) {
            const alpha = (1.0 - dist / bondDistVal) * 0.42;
            ctx.beginPath();
            ctx.moveTo(activeAtoms[i].x, activeAtoms[i].y);
            ctx.lineTo(activeAtoms[j].x, activeAtoms[j].y);
            
            // Draw a beautiful chemical bond (double bonds for CO2, single for H2O/soup)
            ctx.strokeStyle = `rgba(16, 185, 129, ${alpha})`;
            ctx.lineWidth = 1.3;
            ctx.stroke();

            // Double line effect for Carbon-Oxygen double bonds
            if (mixVal === "co2" && (activeAtoms[i].label === "C" || activeAtoms[j].label === "C")) {
              ctx.beginPath();
              ctx.moveTo(activeAtoms[i].x + 3, activeAtoms[i].y + 3);
              ctx.lineTo(activeAtoms[j].x + 3, activeAtoms[j].y + 3);
              ctx.strokeStyle = `rgba(16, 185, 129, ${alpha * 0.5})`;
              ctx.lineWidth = 1.0;
              ctx.stroke();
            }
          }
        }
      }

      activeAtoms.forEach((atom) => {
        // Multiply velocity increments by local kinetic temperature values
        atom.x += atom.vx * tempVal;
        atom.y += atom.vy * tempVal;

        // Container bounds reflection check
        if (atom.x < atom.radius || atom.x > width - atom.radius) {
          atom.vx *= -1;
          atom.x = atom.x < atom.radius ? atom.radius : width - atom.radius;
        }
        if (atom.y < atom.radius || atom.y > height - atom.radius) {
          atom.vy *= -1;
          atom.y = atom.y < atom.radius ? atom.radius : height - atom.radius;
        }

        // Kinetic hover displacement
        if (mouseX > 0) {
          const dx = mouseX - atom.x;
          const dy = mouseY - atom.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 110) {
            const force = (1.0 - dist / 110) * 0.16;
            atom.vx += dx * force * 0.04;
            atom.vy += dy * force * 0.04;
          }
        }

        // Limit kinetic velocity speed cap
        const speed = Math.sqrt(atom.vx * atom.vx + atom.vy * atom.vy);
        const maxVelocity = 2.4 * tempVal;
        if (speed > maxVelocity && speed > 0) {
          atom.vx = (atom.vx / speed) * maxVelocity;
          atom.vy = (atom.vy / speed) * maxVelocity;
        }

        // Render atoms with distinctive element glow effects
        ctx.shadowColor = atom.color;
        ctx.shadowBlur = 5;
        ctx.beginPath();
        ctx.arc(atom.x, atom.y, atom.radius, 0, Math.PI * 2);
        ctx.fillStyle = atom.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Symbol notation
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 8px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(atom.label, atom.x, atom.y);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-[#050508] border border-neutral-900 rounded-2xl overflow-hidden shadow-inner flex flex-col group">
      
      {/* Canvas Header/Status */}
      <div className="relative flex-1 min-h-[170px] bg-neutral-950/20">
        <canvas ref={canvasRef} className="w-full h-full block" />
        <div className="absolute top-3 left-4 flex items-center gap-1.5 px-2 py-0.5 bg-neutral-950/90 border border-neutral-900 rounded text-[9px] text-emerald-400 font-mono uppercase tracking-wider">
          <Activity className="w-2.5 h-2.5 animate-pulse text-emerald-400" />
          Molecular Kinetic Dynamics Simulator
        </div>
      </div>

      {/* Control Deck */}
      <div className="bg-neutral-950/95 border-t border-neutral-900 p-4 space-y-3.5 relative z-10">
        
        {/* Row 1: Compound Mixture Selector */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest font-semibold flex items-center justify-between">
            <span>Molecular Compound Solution</span>
            <span className="text-emerald-400 font-bold">
              {mixture === "soup" ? "ORGANIC SOUP (ALL)" : mixture === "water" ? "WATER (H₂O)" : "CARBON DIOXIDE (CO₂)"}
            </span>
          </label>
          <div className="grid grid-cols-3 gap-1 bg-neutral-900/60 p-0.5 border border-neutral-850 rounded-lg">
            {(["soup", "water", "co2"] as const).map((mix) => (
              <button
                key={mix}
                onClick={() => setMixture(mix)}
                className={`py-1 text-[8px] font-mono rounded uppercase tracking-wider transition-colors cursor-pointer ${
                  mixture === mix
                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold"
                    : "text-neutral-500 hover:text-neutral-300"
                }`}
              >
                {mix === "soup" ? "Soup Mix" : mix === "water" ? "Water" : "CO₂ Gas"}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2: Sliders */}
        <div className="grid grid-cols-2 gap-4">
          {/* Temperature slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Thermal Energy (Speed)</span>
              <span className="text-emerald-400/80 font-bold">{temperature.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="2.5"
              step="0.1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-emerald-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>

          {/* Covalent attraction length slider */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[8px] font-mono text-neutral-500 uppercase tracking-wider">
              <span>Covalent Bond Radius</span>
              <span className="text-emerald-400/80 font-bold">{bondDistance} pm</span>
            </div>
            <input
              type="range"
              min="40"
              max="110"
              step="2"
              value={bondDistance}
              onChange={(e) => setBondDistance(parseInt(e.target.value))}
              className="w-full accent-emerald-400 bg-neutral-900 h-1 rounded-lg cursor-pointer"
            />
          </div>
        </div>

      </div>
    </div>
  );
}

export function HomePage({ 
  email, 
  history, 
  onSearch, 
  onLoadPreset,
  onNavigateToLab,
  onNavigateToContact,
  onClearHistory,
  onSignOut
}: HomePageProps) {
  const [localQuery, setLocalQuery] = useState("");
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [isProfileDrawerOpen, setIsProfileDrawerOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // User credential profile
  const [profile, setProfile] = useState<UserProfile>({
    fullName: "",
    academicRole: "General Science Enthusiast",
    primaryFocus: "None / Universal STEM Scholar",
    affiliation: "Independent Researcher",
    avatarEmoji: "⚛️",
    avatarBgColor: "from-slate-700 to-slate-800",
    joinedDate: ""
  });

  const storageKey = `concept_lab_profile_${email}`;

  // Load profile from local storage based on active user email
  useEffect(() => {
    if (email) {
      try {
        let authCreationDate = "";
        try {
          const auth = getAuth();
          const creationTime = auth.currentUser?.metadata.creationTime;
          if (creationTime) {
            authCreationDate = new Date(creationTime).toLocaleDateString([], { month: "long", day: "numeric", year: "numeric" });
          }
        } catch (e) {
          console.warn("Could not retrieve firebase auth user creation time", e);
        }

        const fallbackDate = authCreationDate || new Date().toLocaleDateString([], { month: "long", year: "numeric" });

        const saved = localStorage.getItem(storageKey);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (authCreationDate && parsed.joinedDate !== authCreationDate) {
            parsed.joinedDate = authCreationDate;
          }
          setProfile(parsed);
        } else {
          const initialProfile: UserProfile = {
            fullName: email.split("@")[0].toUpperCase(),
            academicRole: "General Science Enthusiast",
            primaryFocus: "None / Universal STEM Scholar",
            affiliation: "Home Lab",
            avatarEmoji: AVATAR_EMOJIS[Math.floor(Math.random() * AVATAR_EMOJIS.length)],
            avatarBgColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
            joinedDate: fallbackDate
          };
          setProfile(initialProfile);
          localStorage.setItem(storageKey, JSON.stringify(initialProfile));
        }
      } catch (e) {
        console.warn("Failed to load user profile", e);
      }
    }
  }, [email, storageKey]);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      localStorage.setItem(storageKey, JSON.stringify(profile));
      setIsEditing(false);
      triggerToast("Academic Credentials Saved!");
    } catch (e) {
      triggerToast("Failed to save credentials.");
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const handleLocalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (localQuery.trim()) {
      onSearch(localQuery.trim());
    }
  };

  const handlePresetTrigger = (preset: string) => {
    onSearch(preset);
  };

  return (
    <div className="w-full relative bg-[#040408] text-slate-200 font-sans selection:bg-cyan-500/25 selection:text-cyan-200 overflow-x-hidden min-h-screen flex flex-col">
      
      {/* Dynamic Contoured Atmospheric Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-950/15 via-[#040408] to-[#040408] pointer-events-none z-0" />

      {/* Sticky Premium Navbar */}
      <nav className="sticky top-0 z-40 w-full border-b border-neutral-900/60 bg-neutral-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 md:px-8 py-3.5 flex items-center justify-between">
          
          {/* Logo element */}
          <div className="flex items-center gap-3 cursor-pointer group" onClick={onNavigateToLab}>
            <QuanthosLogo size="lg" className="transition-transform group-hover:scale-105" />
            <span className="font-display font-black tracking-widest text-white text-base">QUANTHOS</span>
          </div>

          {/* Nav Links */}
          <div className="hidden md:flex items-center gap-8 text-[11px] font-mono uppercase tracking-wider text-neutral-400">
            <a href="#capabilities" className="hover:text-cyan-400 transition-colors">Capabilities</a>
            <a href="#modules" className="hover:text-cyan-400 transition-colors">Modules</a>
            {email && (
              <button 
                onClick={onNavigateToContact}
                className="hover:text-cyan-400 transition-colors uppercase cursor-pointer text-[11px] font-mono"
              >
                Contact
              </button>
            )}
          </div>

          {/* Right Actions - Consolidated Dropdown Menu (3 Lines / Hamburger) */}
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center justify-center p-2 bg-neutral-900 border border-neutral-850 hover:border-cyan-500/30 text-neutral-300 hover:text-cyan-400 rounded-lg cursor-pointer transition-all shrink-0 shadow-md relative z-50"
              title="Menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <AnimatePresence>
              {isDropdownOpen && (
                <>
                  {/* Backdrop click to close */}
                  <div 
                    className="fixed inset-0 z-40 cursor-default" 
                    onClick={() => setIsDropdownOpen(false)} 
                  />
                  
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-48 bg-neutral-950 border border-neutral-900 rounded-xl p-1.5 shadow-2xl shadow-black/80 z-50 text-left font-mono"
                  >
                    {/* Logged in info display */}
                    {email && (
                      <div className="px-3 py-2 border-b border-neutral-900/60 mb-1 text-[10px] text-neutral-500 truncate max-w-full">
                        Scholar: <span className="text-neutral-300 block font-sans truncate mt-0.5">{email}</span>
                      </div>
                    )}

                    {/* Profile Option */}
                    {email ? (
                      <button
                        onClick={() => {
                          setIsProfileDrawerOpen(true);
                          setIsDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-neutral-300 hover:text-cyan-400 hover:bg-cyan-500/5 rounded-lg text-xs transition-colors cursor-pointer text-left"
                      >
                        <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>Profile Settings</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          const authPanel = document.getElementById("scholar-auth-card");
                          if (authPanel) {
                            authPanel.scrollIntoView({ behavior: "smooth" });
                          }
                          setIsDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-neutral-300 hover:text-cyan-400 hover:bg-cyan-500/5 rounded-lg text-xs transition-colors cursor-pointer text-left"
                      >
                        <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>Sign In</span>
                      </button>
                    )}

                    {/* Contact Us Option */}
                    {email && (
                      <button
                        onClick={() => {
                          onNavigateToContact();
                          setIsDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-neutral-300 hover:text-cyan-400 hover:bg-cyan-500/5 rounded-lg text-xs transition-colors cursor-pointer text-left"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>Contact Us</span>
                      </button>
                    )}

                    {/* Sign Out Option */}
                    {email && (
                      <div className="border-t border-neutral-900/60 mt-1 pt-1">
                        <button
                          onClick={() => {
                            onSignOut();
                            setIsDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/5 rounded-lg text-xs transition-colors cursor-pointer text-left"
                        >
                          <svg className="w-3.5 h-3.5 text-red-500 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                          </svg>
                          <span>Sign Out</span>
                        </button>
                      </div>
                    )}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </nav>

      {/* SECTION 1: HERO VIEW CONTAINER */}
      <header className="relative w-full py-20 md:py-28 overflow-hidden flex flex-col items-center justify-center text-center px-4 z-10 border-b border-neutral-900/40">
        
        {/* Animated Wireframe Topographic Mesh background */}
        <HeroWaveBackground />

        {/* Content stack */}
        <div className="max-w-4xl mx-auto flex flex-col items-center gap-6 relative z-10">
          
          {/* Tagline Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1 bg-cyan-950/40 border border-cyan-900/40 rounded-full text-[10px] text-cyan-400 font-mono tracking-widest uppercase shadow-inner">
              <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse" />
              Interactive 3D Science Laboratory
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-4xl md:text-6xl font-black font-display text-white tracking-tight leading-[1.1] max-w-3xl"
          >
            Explore Science <br />
            In <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-400 drop-shadow-[0_0_15px_rgba(34,211,238,0.2)]">Three Dimensions</span>
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-sm md:text-base text-neutral-400 max-w-2xl leading-relaxed"
          >
            Quanthos is your gateway to immersive physics, mathematics, and chemistry simulations - built for students, researchers, and explorers.
          </motion.p>

          {/* Console-Style Compilation Form */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="w-full max-w-xl bg-neutral-950/80 border border-neutral-900 p-1.5 rounded-2xl shadow-2xl flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mt-4"
          >
            <form onSubmit={handleLocalSubmit} className="flex flex-1 items-center gap-2 px-3">
              <QuanthosLogo size="xs" className="opacity-50 shrink-0" />
              <input
                type="text"
                placeholder="Query any STEM topic... (e.g., Bohr atomic model, Double pendulum)"
                value={localQuery}
                onChange={(e) => setLocalQuery(e.target.value)}
                className="w-full bg-transparent text-slate-200 text-xs py-2 focus:outline-none placeholder:text-neutral-600 font-sans"
              />
            </form>
            <button
              onClick={handleLocalSubmit}
              disabled={!localQuery.trim()}
              className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 font-mono font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
            >
              <span>Compile</span>
              <Zap className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
            </button>
          </motion.div>

          {/* Hot topic shortcuts */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-wrap gap-2 items-center justify-center text-[10px] text-neutral-500 font-mono mt-1"
          >
            <span className="uppercase tracking-wider">Syllabus hot topics:</span>
            <button onClick={() => handlePresetTrigger("Coulombs Law electrostatics")} className="px-2 py-0.5 bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 hover:border-cyan-500/30 rounded text-cyan-400/80 hover:text-cyan-400 transition-colors cursor-pointer">Coulomb's Law</button>
            <button onClick={() => handlePresetTrigger("DNA Double Helix structure")} className="px-2 py-0.5 bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 hover:border-rose-500/30 rounded text-rose-400/80 hover:text-rose-400 transition-colors cursor-pointer">DNA Helix</button>
            <button onClick={() => handlePresetTrigger("Fourier Series wave synthesis equations")} className="px-2 py-0.5 bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 hover:border-violet-500/30 rounded text-violet-400/80 hover:text-violet-400 transition-colors cursor-pointer">Fourier Waves</button>
          </motion.div>

          {/* Bottom Action Row and scroll helper */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-col items-center gap-4 mt-8"
          >
            <button
              onClick={onNavigateToLab}
              className="px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-neutral-950 font-display font-black text-xs uppercase tracking-wider rounded-2xl shadow-xl hover:shadow-cyan-500/10 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Enter Laboratory</span>
              <ArrowRight className="w-4 h-4 text-neutral-950 stroke-[3]" />
            </button>

            <div className="flex items-center gap-1.5 text-[9px] font-mono uppercase tracking-widest text-neutral-600 animate-pulse mt-4">
              <span>Scroll to Explore</span>
              <span>↓</span>
            </div>
          </motion.div>
        </div>
      </header>

      {/* SECTION 2: CAPABILITIES GRID */}
      <section id="capabilities" className="w-full max-w-7xl mx-auto px-6 md:px-8 py-20 relative z-10 border-b border-neutral-900/40">
        
        {/* Label and titles */}
        <div className="text-center max-w-2xl mx-auto flex flex-col gap-3 mb-16">
          <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase font-bold">Capabilities</span>
          <h2 className="text-2xl md:text-3xl font-black font-display text-white tracking-tight">
            Everything You Need to Simulate Reality
          </h2>
          <p className="text-xs md:text-sm text-neutral-400 leading-relaxed">
            From quantum mechanics to calculus visualizations - Quanthos renders complexity into clarity.
          </p>
        </div>

        {/* 3x2 Grid of capabilities with Framer Motion staggered entrance and premium interactive triggers */}
        <motion.div 
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          variants={{
            hidden: { opacity: 0 },
            show: {
              opacity: 1,
              transition: {
                staggerChildren: 0.08
              }
            }
          }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          
          {/* Card 1: Physics Engine */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 15 },
              show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 90, damping: 15 } }
            }}
            whileHover={{ y: -5, borderColor: "rgba(34, 211, 238, 0.3)" }}
            className="bg-neutral-950/40 hover:bg-neutral-950/75 border border-neutral-900 p-6 rounded-2xl flex flex-col gap-4 transition-colors duration-300 group cursor-default"
          >
            <div className="p-2.5 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded-xl w-10 h-10 flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Atom className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-display text-neutral-200">Physics Engine</h3>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Real-time simulation of Newtonian mechanics, electromagnetism, wave propagation, and quantum state visualization.
              </p>
            </div>
          </motion.div>

          {/* Card 2: Math Visualizer */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 15 },
              show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 90, damping: 15 } }
            }}
            whileHover={{ y: -5, borderColor: "rgba(139, 92, 246, 0.3)" }}
            className="bg-neutral-950/40 hover:bg-neutral-950/75 border border-neutral-900 p-6 rounded-2xl flex flex-col gap-4 transition-colors duration-300 group cursor-default"
          >
            <div className="p-2.5 bg-violet-500/10 text-violet-400 border border-violet-500/20 rounded-xl w-10 h-10 flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Sliders className="w-5 h-5 text-violet-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-display text-neutral-200">Math Visualizer</h3>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Plot multivariable calculus, 3D geometry, Fourier transforms, and live equation rendering in real-time.
              </p>
            </div>
          </motion.div>

          {/* Card 3: Chem Simulator */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 15 },
              show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 90, damping: 15 } }
            }}
            whileHover={{ y: -5, borderColor: "rgba(16, 185, 129, 0.3)" }}
            className="bg-neutral-950/40 hover:bg-neutral-950/75 border border-neutral-900 p-6 rounded-2xl flex flex-col gap-4 transition-colors duration-300 group cursor-default"
          >
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl w-10 h-10 flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Layers className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-display text-neutral-200">Chem Simulator</h3>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Model molecular bonds, electron orbitals, periodic table interactions, and 3D molecular geometry.
              </p>
            </div>
          </motion.div>

          {/* Card 4: AI Guidance */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 15 },
              show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 90, damping: 15 } }
            }}
            whileHover={{ y: -5, borderColor: "rgba(245, 158, 11, 0.3)" }}
            className="bg-neutral-950/40 hover:bg-neutral-950/75 border border-neutral-900 p-6 rounded-2xl flex flex-col gap-4 transition-colors duration-300 group cursor-default"
          >
            <div className="p-2.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-xl w-10 h-10 flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Cpu className="w-5 h-5 text-amber-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-display text-neutral-200">AI Guidance</h3>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Get intelligent hints, step-by-step breakdowns, and predictive analysis of your simulation in progress.
              </p>
            </div>
          </motion.div>

          {/* Card 5: Live Collaboration */}
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 15 },
              show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 90, damping: 15 } }
            }}
            whileHover={{ y: -5, borderColor: "rgba(59, 130, 246, 0.3)" }}
            className="bg-neutral-950/40 hover:bg-neutral-950/75 border border-neutral-900 p-6 rounded-2xl flex flex-col gap-4 transition-colors duration-300 group cursor-default"
          >
            <div className="p-2.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-xl w-10 h-10 flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Sparkles className="w-5 h-5 text-blue-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-display text-neutral-200">Live Collaboration</h3>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Share simulation sessions in real time. Annotate, co-edit, and discuss findings with your lab partners.
              </p>
            </div>
          </motion.div>

        </motion.div>
      </section>

      {/* SECTION 3: ALTERNATING DISCIPLINES MODULES */}
      <section id="modules" className="w-full max-w-7xl mx-auto px-6 md:px-8 py-20 relative z-10 border-b border-neutral-900/40">
        
        {/* Title stack */}
        <div className="text-center max-w-2xl mx-auto flex flex-col gap-3 mb-20">
          <span className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase font-bold">Modules</span>
          <h2 className="text-2xl md:text-3xl font-black font-display text-white tracking-tight">
            Three Disciplines. One Platform.
          </h2>
        </div>

        {/* Modules content stack */}
        <div className="flex flex-col gap-24">
          
          {/* Row 1: Physics (01 / PHYSICS) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Visual simulation canvas */}
            <div className="lg:col-span-5 h-[320px] sm:h-[350px] w-full order-last lg:order-first">
              <PhysicsWaveVisualizer />
            </div>
            {/* Explanatory notes */}
            <div className="lg:col-span-7 flex flex-col gap-4 text-left">
              <span className="text-[10px] font-mono text-cyan-400/80 font-bold uppercase tracking-wider">01 / Physics</span>
              <h3 className="text-xl md:text-2xl font-black font-display text-white tracking-tight leading-tight">
                Newtonian Mechanics & Wave Propagation
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Simulate orbital paths, collision models, electromagnetic fields, and wave interference patterns with full 3D interactivity and slow-motion replay.
              </p>
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mt-1">
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Orbital</span>
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Waves</span>
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">3D Rendering</span>
              </div>
            </div>
          </div>

          {/* Row 2: Mathematics (02 / MATHEMATICS) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Explanatory notes */}
            <div className="lg:col-span-7 flex flex-col gap-4 text-left">
              <span className="text-[10px] font-mono text-violet-400/80 font-bold uppercase tracking-wider">02 / Mathematics</span>
              <h3 className="text-xl md:text-2xl font-black font-display text-white tracking-tight leading-tight">
                3D Calculus & Geometric Algebra
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Visualize multivariable functions, tangent planes, vector fields, and Fourier series interactively. Solve equations and watch them come alive.
              </p>
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mt-1">
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Calculus</span>
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Linear Algebra</span>
              </div>
            </div>
            {/* Visual simulation canvas */}
            <div className="lg:col-span-5 h-[320px] sm:h-[350px] w-full">
              <MathFourierVisualizer />
            </div>
          </div>

          {/* Row 3: Chemistry (03 / CHEMISTRY) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Visual simulation canvas */}
            <div className="lg:col-span-5 h-[320px] sm:h-[350px] w-full order-last lg:order-first">
              <ChemistryBondVisualizer />
            </div>
            {/* Explanatory notes */}
            <div className="lg:col-span-7 flex flex-col gap-4 text-left">
              <span className="text-[10px] font-mono text-emerald-400/80 font-bold uppercase tracking-wider">03 / Chemistry</span>
              <h3 className="text-xl md:text-2xl font-black font-display text-white tracking-tight leading-tight">
                Molecular Dynamics & Reaction Kinetics
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Explore molecular orbital theory, bond energy, periodic trends, and live chemical reactions in a 3D atomic environment.
              </p>
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mt-1">
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Molecular</span>
                <span className="px-2.5 py-0.5 bg-neutral-950 border border-neutral-850 rounded text-[9px] font-mono text-neutral-400 uppercase tracking-wide">Kinetics</span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* FOOTER */}
      <footer className="w-full border-t border-neutral-900/60 bg-neutral-950/25 py-8 mt-auto relative z-10 text-xs text-neutral-500 font-mono">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <QuanthosLogo size="sm" className="opacity-60" />
            <span className="font-sans font-bold tracking-wider text-neutral-400">QUANTHOS</span>
          </div>
          <div>
            <span>© 2026 Quanthos Labs. All rights reserved.</span>
          </div>
        </div>
      </footer>

      {/* DYNAMIC SIDE-DRAWER SLIDE PANEL (PROFILE / ACCREDITATION STATUS) */}
      <AnimatePresence>
        {isProfileDrawerOpen && (
          <>
            {/* Backdrop lock */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsProfileDrawerOpen(false);
                setIsEditing(false);
              }}
              className="fixed inset-0 bg-black z-40"
            />

            {/* Slide over tray */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="fixed right-0 top-0 bottom-0 w-full sm:w-[420px] bg-[#09090e] border-l border-neutral-900 shadow-2xl z-50 p-6 flex flex-col gap-6 overflow-y-auto"
            >
              
              {/* Drawer header */}
              <div className="flex items-center justify-between border-b border-neutral-900 pb-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-300">Scholar Command Pass</span>
                </div>
                <button
                  onClick={() => {
                    setIsProfileDrawerOpen(false);
                    setIsEditing(false);
                  }}
                  className="p-1 hover:bg-neutral-900 border border-transparent hover:border-neutral-800 text-neutral-500 hover:text-neutral-300 rounded-lg transition-all cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Editable profile card or normal display */}
              {!isEditing ? (
                <div className="space-y-6">
                  {/* Visual credential badge card */}
                  <div className="bg-gradient-to-b from-neutral-900/90 to-neutral-950/80 border border-neutral-850 p-5 rounded-2xl relative overflow-hidden group">
                    <div className="absolute top-2 right-2 flex items-center gap-1.5 px-2 py-0.5 bg-neutral-950/80 border border-neutral-900 rounded text-[8px] font-mono text-cyan-400">
                      <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse" />
                      SECURE PASS
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {/* Avatar */}
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-tr ${profile.avatarBgColor} flex items-center justify-center text-2.5xl shadow-lg border border-white/10`}>
                        {profile.avatarEmoji}
                      </div>
                      
                      <div className="space-y-1 min-w-0">
                        <h4 className="text-sm font-bold text-white truncate">{profile.fullName || "GUEST SCHOLAR"}</h4>
                        <p className="text-[10px] text-cyan-400 font-mono tracking-wider truncate uppercase">{profile.academicRole}</p>
                      </div>
                    </div>

                    <div className="border-t border-neutral-900/60 mt-4 pt-4 space-y-2 text-[11px] font-mono">
                      <div className="flex justify-between">
                        <span className="text-neutral-500">PRIMARY FIELD:</span>
                        <span className="text-neutral-300 text-right truncate max-w-[180px]">{profile.primaryFocus}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">AFFILIATION:</span>
                        <span className="text-neutral-300 text-right truncate max-w-[180px]">{profile.affiliation}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">COMMISSIONED:</span>
                        <span className="text-neutral-300">{profile.joinedDate}</span>
                      </div>
                    </div>

                    {/* Edit button */}
                    <button
                      onClick={() => setIsEditing(true)}
                      className="w-full mt-4 py-2 bg-neutral-900 hover:bg-neutral-850 hover:border-neutral-700 text-neutral-300 hover:text-white border border-neutral-800 text-[11px] font-mono uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3 text-cyan-400" />
                      Modify Credentials
                    </button>
                  </div>

                  {/* Saved simulation history archive */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono tracking-wider text-neutral-400 uppercase">Simulation History ({history.length})</span>
                      {history.length > 0 && (
                        <button
                          onClick={onClearHistory}
                          className="text-[9px] font-mono text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          Purge All
                        </button>
                      )}
                    </div>

                    {history.length > 0 ? (
                      <div className="flex flex-col gap-2 max-h-[300px] overflow-y-auto scrollbar-thin">
                        {history.map((item) => (
                          <div
                            key={item.id}
                            onClick={() => {
                              onSearch(item.topic);
                              setIsProfileDrawerOpen(false);
                            }}
                            className="p-3 bg-neutral-950/60 hover:bg-neutral-950 border border-neutral-900 hover:border-cyan-500/20 text-xs rounded-xl transition-all cursor-pointer flex items-center justify-between group"
                          >
                            <div className="flex items-center gap-2 truncate">
                              <QuanthosLogo size="xs" className="opacity-50 group-hover:opacity-100 transition-opacity shrink-0" />
                              <div className="truncate text-left">
                                <p className="truncate text-neutral-300 group-hover:text-cyan-300 transition-colors">{item.topic}</p>
                                <span className="text-[9px] text-neutral-600 font-mono">{item.timestamp}</span>
                              </div>
                            </div>
                            <ChevronRight className="w-3 h-3 text-neutral-600 group-hover:text-cyan-400 transition-colors" />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-12 text-center text-neutral-600 border border-dashed border-neutral-900 rounded-2xl flex flex-col items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-neutral-700" />
                        <span className="text-xs">No local archives compiled.</span>
                        <span className="text-[10px] leading-relaxed max-w-[220px] text-neutral-700">Type any concept in the hero search box to generate a real-time, sandbox simulation!</span>
                      </div>
                    )}
                  </div>

                  {/* Sign out */}
                  <button
                    onClick={() => {
                      onSignOut();
                      setIsProfileDrawerOpen(false);
                    }}
                    className="w-full py-2.5 bg-red-950/15 hover:bg-red-950/30 text-red-400 hover:text-red-300 border border-red-900/20 hover:border-red-900/40 text-xs font-mono uppercase tracking-wider rounded-xl transition-all cursor-pointer"
                  >
                    Disconnect Lab Session
                  </button>
                </div>
              ) : (
                /* Modify profile form */
                <form onSubmit={handleSaveProfile} className="space-y-4 text-left">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Scholar Full Name</label>
                    <input
                      type="text"
                      value={profile.fullName}
                      onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                      placeholder="e.g. Dr. Richard Feynman"
                      className="w-full bg-neutral-950 border border-neutral-850 text-neutral-200 text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-cyan-500 font-sans"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Academic Role / Standing</label>
                    <select
                      value={profile.academicRole}
                      onChange={(e) => setProfile({ ...profile, academicRole: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-850 text-neutral-300 text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-cyan-500 font-sans"
                    >
                      {ACADEMIC_ROLES.map((role) => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Primary Scientific Focus</label>
                    <select
                      value={profile.primaryFocus}
                      onChange={(e) => setProfile({ ...profile, primaryFocus: e.target.value })}
                      className="w-full bg-neutral-950 border border-neutral-850 text-neutral-300 text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-cyan-500 font-sans"
                    >
                      {RESEARCH_FOCUSES.map((focus) => (
                        <option key={focus} value={focus}>{focus}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Institution / Affiliation</label>
                    <input
                      type="text"
                      value={profile.affiliation}
                      onChange={(e) => setProfile({ ...profile, affiliation: e.target.value })}
                      placeholder="e.g. CERN Laboratory"
                      className="w-full bg-neutral-950 border border-neutral-850 text-neutral-200 text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-cyan-500 font-sans"
                    />
                  </div>

                  {/* Avatar Emoji picker */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Select Avatar Emoji</label>
                    <div className="grid grid-cols-6 gap-2 bg-neutral-950 p-2.5 rounded-xl border border-neutral-850">
                      {AVATAR_EMOJIS.map((emoji) => (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => setProfile({ ...profile, avatarEmoji: emoji })}
                          className={`text-xl p-1 rounded-lg transition-all ${profile.avatarEmoji === emoji ? "bg-neutral-800 scale-110 border border-neutral-700" : "hover:bg-neutral-900/60"}`}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Avatar BG Color picker */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-neutral-500 uppercase tracking-wide">Select Avatar Gradient Theme</label>
                    <div className="grid grid-cols-4 gap-2 bg-neutral-950 p-2.5 rounded-xl border border-neutral-850">
                      {AVATAR_COLORS.map((bg) => (
                        <button
                          key={bg}
                          type="button"
                          onClick={() => setProfile({ ...profile, avatarBgColor: bg })}
                          className={`h-7 rounded-lg bg-gradient-to-tr ${bg} transition-all border ${profile.avatarBgColor === bg ? "border-white scale-105" : "border-transparent"}`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Save row */}
                  <div className="flex gap-2.5 pt-4">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-400 text-xs font-mono uppercase tracking-wider rounded-xl transition-all cursor-pointer text-center"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 text-xs font-mono font-bold uppercase tracking-wider rounded-xl shadow-lg transition-all cursor-pointer text-center"
                    >
                      Save Pass
                    </button>
                  </div>
                </form>
              )}

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Interactive Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="fixed bottom-6 left-1/2 -translate-y-1/2 -translate-x-1/2 bg-neutral-950 border border-neutral-850 text-neutral-200 text-xs px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 font-mono z-50 shadow-cyan-950/25"
          >
            <Check className="w-4 h-4 text-cyan-400" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
