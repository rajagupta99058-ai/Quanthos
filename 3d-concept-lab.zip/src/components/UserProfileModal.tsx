import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { getAuth } from "firebase/auth";
import {
  User,
  GraduationCap,
  Award,
  Calendar,
  X,
  Flame,
  Sparkles,
  Save,
  Edit2,
  Atom,
  MapPin,
  Briefcase,
  Clock,
  BookOpen,
  LogOut
} from "lucide-react";
import { UserProfile, SavedHistoryItem } from "../types";

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
  history: SavedHistoryItem[];
  onClearHistory: () => void;
  onSelectHistory: (item: SavedHistoryItem) => void;
  onSignOut: () => void;
}

const ACADEMIC_ROLES = [
  "Quantum Engineer",
  "Astro-Physicist",
  "Undergraduate Student",
  "Graduate Researcher",
  "Academic Professor",
  "Space Hobbyist",
  "Data Scientist",
  "STEM Educator",
  "General Science Enthusiast"
];

const RESEARCH_FOCUSES = [
  "Chaos Theory & Dynamic Systems",
  "Celestial Mechanics & Keplerian Gravity",
  "Wave Optics & Physical Wave Mechanics",
  "Hydrostatics & Transverse Stability",
  "Thermodynamics & Statistical Mechanics",
  "Quantum Mechanics & Particle Interactions",
  "Electromagnetism & Coulomb Forces",
  "None / Universal STEM Scholar"
];

const AVATAR_EMOJIS = ["🧬", "⚛️", "🪐", "🌌", "🧪", "📡", "🛸", "🧠", "⚓", "📐", "🚀"];
const AVATAR_COLORS = [
  "from-indigo-500 to-purple-600",
  "from-cyan-500 to-blue-600",
  "from-emerald-500 to-teal-600",
  "from-pink-500 to-rose-600",
  "from-amber-500 to-orange-600",
  "from-fuchsia-500 to-purple-800"
];

export default function UserProfileModal({
  isOpen,
  onClose,
  email,
  history,
  onClearHistory,
  onSelectHistory,
  onSignOut
}: UserProfileModalProps) {
  const [profile, setProfile] = useState<UserProfile>({
    fullName: "",
    academicRole: "General Science Enthusiast",
    primaryFocus: "None / Universal STEM Scholar",
    affiliation: "Independent Researcher",
    avatarEmoji: "⚛️",
    avatarBgColor: "from-indigo-500 to-purple-600",
    joinedDate: new Date().toLocaleDateString([], { month: "long", year: "numeric" })
  });

  const [isEditing, setIsEditing] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const storageKey = `concept_lab_profile_${email}`;

  // Load profile from local storage based on the active user email
  useEffect(() => {
    if (email) {
      try {
        let authCreationDate = "";
        try {
          const auth = getAuth();
          const creationTime = auth.currentUser?.metadata.creationTime;
          if (creationTime) {
            authCreationDate = new Date(creationTime).toLocaleDateString([], { month: "long", day: "numeric", year: "numeric" });
          }
        } catch (e) {
          console.warn("Could not retrieve firebase auth user creation time", e);
        }

        const fallbackDate = authCreationDate || new Date().toLocaleDateString([], { month: "long", year: "numeric" });

        const saved = localStorage.getItem(storageKey);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (authCreationDate && parsed.joinedDate !== authCreationDate) {
            parsed.joinedDate = authCreationDate;
          }
          setProfile(parsed);
        } else {
          // Initialize fresh profile for this specific user email
          const initialProfile: UserProfile = {
            fullName: email.split("@")[0].toUpperCase(),
            academicRole: "General Science Enthusiast",
            primaryFocus: "None / Universal STEM Scholar",
            affiliation: "Home Lab",
            avatarEmoji: AVATAR_EMOJIS[Math.floor(Math.random() * AVATAR_EMOJIS.length)],
            avatarBgColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
            joinedDate: fallbackDate
          };
          setProfile(initialProfile);
          localStorage.setItem(storageKey, JSON.stringify(initialProfile));
        }
      } catch (e) {
        console.warn("Failed to load user profile from cache", e);
      }
    }
  }, [email, storageKey]);

  // Save profile helper
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      localStorage.setItem(storageKey, JSON.stringify(profile));
      setIsEditing(false);
      triggerToast("Academic Credentials Updated successfully!");
    } catch (e) {
      triggerToast("Failed to save profile changes.");
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  // Calculate dynamic lab level based on history count
  const getLabRank = (count: number) => {
    if (count === 0) return { title: "Novice Apprentice", icon: "🌱", desc: "Start exploring STEM theories to build your credentials." };
    if (count <= 2) return { title: "Entropy Explorer", icon: "🌀", desc: "Actively investigating chaotic systems and basic motion." };
    if (count <= 5) return { title: "Relativistic Voyager", icon: "🛸", desc: "Grasping advanced space-time manifolds and Kepler physics." };
    return { title: "Quantum Sage", icon: "🌌", desc: "Elite research specialist with deep mathematical command." };
  };

  const rank = getLabRank(history.length);

  // Export history logbook as structured JSON report
  const handleExportData = () => {
    try {
      const exportObject = {
        researcher: {
          email,
          ...profile,
        },
        labActivitySummary: {
          totalConceptsSimulated: history.length,
          labRank: rank.title,
          exportTimestamp: new Date().toLocaleString()
        },
        simulationHistory: history.map((h) => ({
          topic: h.topic,
          simulationExplanation: h.simulation.explanation,
          timestamp: h.timestamp,
          sourceCodeExcerpt: h.simulation.threeJsCode.substring(0, 500) + "..."
        }))
      };

      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObject, null, 2));
      const downloadAnchor = document.createElement("a");
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `3D_Concept_Lab_Report_${profile.fullName.replace(/\s+/g, "_")}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      triggerToast("Academic lab log report exported successfully!");
    } catch (e) {
      triggerToast("Export failed.");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/75 backdrop-blur-md cursor-pointer"
          />

          {/* Modal Window Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-2xl bg-neutral-950/90 border border-neutral-850 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-neutral-100 z-10"
          >
          {/* Top holographic glowing bar */}
          <div className="absolute -top-[1px] inset-x-12 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />

          {/* Modal Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-900 bg-neutral-950/50 backdrop-blur">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                <Atom className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-display font-bold tracking-tight text-white">
                  Scientific Command Profile
                </h3>
                <p className="text-[10px] text-neutral-500 font-mono tracking-wider">
                  RESEARCHER ID: {email.split("@")[0].toUpperCase()}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onSignOut();
                  onClose();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 hover:border-red-800/40 text-red-400 font-display font-medium text-xs rounded-xl cursor-pointer transition-all active:scale-95 shadow-sm"
                title="Sign Out of Lab Session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-200 hover:bg-neutral-900 active:scale-95 transition-all cursor-pointer"
                title="Close Profile"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Content - Scrollable */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            
            <div className="space-y-6">
                
                {/* Visual Passport Profile Card */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-neutral-900/60 to-neutral-950 border border-neutral-850/80 shadow-lg relative overflow-hidden flex flex-col sm:flex-row gap-5 items-center sm:items-start">
                  
                  {/* Glowing background halo */}
                  <div className="absolute top-0 right-0 w-44 h-44 bg-indigo-500/5 rounded-full blur-[40px] pointer-events-none" />
                  
                  {/* Avatar Icon Sphere */}
                  <div className={`w-20 h-20 rounded-2xl bg-gradient-to-tr ${profile.avatarBgColor} p-0.5 shadow-xl shrink-0`}>
                    <div className="w-full h-full bg-neutral-950/80 rounded-[14px] flex items-center justify-center text-4xl select-none">
                      {profile.avatarEmoji}
                    </div>
                  </div>

                  {/* Passport core stats */}
                  <div className="flex-1 text-center sm:text-left space-y-2">
                    <div className="space-y-0.5">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 justify-center sm:justify-start">
                        <h4 className="text-lg font-display font-bold text-white tracking-tight">
                          {profile.fullName || "UNREGISTERED SCHOLAR"}
                        </h4>
                        <span className="px-2 py-0.5 text-[9px] bg-indigo-950/50 text-indigo-400 border border-indigo-900/40 rounded-full font-mono font-bold uppercase self-center tracking-wider">
                          Rank: {rank.title}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 flex items-center justify-center sm:justify-start gap-1">
                        <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                        {profile.academicRole}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 pt-2 border-t border-neutral-900/60 text-xs text-neutral-400 font-sans">
                      <div className="flex items-center gap-2 justify-center sm:justify-start">
                        <Briefcase className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span className="truncate">Affiliation: <strong>{profile.affiliation || "Home Lab"}</strong></span>
                      </div>
                      <div className="flex items-center gap-2 justify-center sm:justify-start">
                        <Clock className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span>Joined: <strong>{profile.joinedDate}</strong></span>
                      </div>
                      <div className="flex items-center gap-2 justify-center sm:justify-start sm:col-span-2">
                        <BookOpen className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span className="truncate">Focus: <strong className="text-cyan-400/90">{profile.primaryFocus}</strong></span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Gamified Achievements Shelf */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-display font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-amber-400" />
                    Holographic Research Milestones
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    
                    {/* Achievement 1: Lab exploration streak */}
                    <div className="p-3.5 rounded-xl bg-neutral-900/40 border border-neutral-900 flex items-center gap-3">
                      <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg shrink-0">
                        <Flame className="w-4 h-4" />
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-[10px] text-neutral-500 font-mono">SIMULATION STREAK</p>
                        <p className="text-sm font-bold text-neutral-200">
                          {history.length > 0 ? "Active Logbook" : "0 Runs"}
                        </p>
                      </div>
                    </div>

                    {/* Achievement 2: Level calculated rank */}
                    <div className="p-3.5 rounded-xl bg-neutral-900/40 border border-neutral-900 flex items-center gap-3 sm:col-span-2">
                      <span className="text-2xl">{rank.icon}</span>
                      <div className="space-y-0.5">
                        <p className="text-[10px] text-neutral-500 font-mono uppercase">LAB LEVEL ACHIEVEMENT</p>
                        <p className="text-xs font-bold text-indigo-300">{rank.title}</p>
                        <p className="text-[10px] text-neutral-400 leading-none">{rank.desc}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Edit Form Toggle or details form */}
                {!isEditing ? (
                  <div className="flex justify-start">
                    <button
                      type="button"
                      onClick={() => setIsEditing(true)}
                      className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 hover:border-neutral-700 text-xs text-neutral-300 font-display font-semibold transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-cyan-400" />
                      Revise Academic Credentials
                    </button>
                  </div>
                ) : (
                  <motion.form
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    onSubmit={handleSaveProfile}
                    className="p-4 rounded-xl bg-neutral-900/40 border border-neutral-850 space-y-4 text-left"
                  >
                    <h5 className="text-xs font-display font-bold text-white uppercase tracking-wider border-b border-neutral-800 pb-1.5 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                      Edit Academic Credentials
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Name input */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                          Academic Alias / Name
                        </label>
                        <input
                          type="text"
                          required
                          value={profile.fullName}
                          onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                          className="w-full bg-neutral-950 text-xs px-3 py-2 rounded-lg border border-neutral-800 focus:outline-none focus:border-cyan-500 text-neutral-200"
                        />
                      </div>

                      {/* Affiliation */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                          Institutional Affiliation
                        </label>
                        <input
                          type="text"
                          value={profile.affiliation}
                          onChange={(e) => setProfile({ ...profile, affiliation: e.target.value })}
                          placeholder="Home Lab"
                          className="w-full bg-neutral-950 text-xs px-3 py-2 rounded-lg border border-neutral-800 focus:outline-none focus:border-cyan-500 text-neutral-200"
                        />
                      </div>

                      {/* Academic Role Dropdown */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                          Academic Role
                        </label>
                        <select
                          value={profile.academicRole}
                          onChange={(e) => setProfile({ ...profile, academicRole: e.target.value })}
                          className="w-full bg-neutral-950 text-xs px-3 py-2 rounded-lg border border-neutral-800 focus:outline-none focus:border-cyan-500 text-neutral-200 cursor-pointer"
                        >
                          {ACADEMIC_ROLES.map((role) => (
                            <option key={role} value={role}>
                              {role}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Research Focus Dropdown */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                          Primary Research Focus
                        </label>
                        <select
                          value={profile.primaryFocus}
                          onChange={(e) => setProfile({ ...profile, primaryFocus: e.target.value })}
                          className="w-full bg-neutral-950 text-xs px-3 py-2 rounded-lg border border-neutral-800 focus:outline-none focus:border-cyan-500 text-neutral-200 cursor-pointer"
                        >
                          {RESEARCH_FOCUSES.map((focus) => (
                            <option key={focus} value={focus}>
                              {focus}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Avatar Customization */}
                    <div className="space-y-2 pt-2 border-t border-neutral-900/60">
                      <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                        Select Core Emblem Avatar
                      </label>
                      <div className="flex flex-wrap gap-1.5">
                        {AVATAR_EMOJIS.map((emoji) => (
                          <button
                            type="button"
                            key={emoji}
                            onClick={() => setProfile({ ...profile, avatarEmoji: emoji })}
                            className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg hover:bg-neutral-800/80 active:scale-90 transition-all cursor-pointer ${
                              profile.avatarEmoji === emoji ? "bg-cyan-950 border border-cyan-500/50" : "bg-neutral-950 border border-neutral-900"
                            }`}
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block">
                        Select Profile Aura Gradient
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {AVATAR_COLORS.map((bg) => (
                          <button
                            type="button"
                            key={bg}
                            onClick={() => setProfile({ ...profile, avatarBgColor: bg })}
                            className={`w-8 h-8 rounded-full bg-gradient-to-tr ${bg} border transition-all active:scale-90 cursor-pointer ${
                              profile.avatarBgColor === bg ? "border-white scale-110 shadow-lg" : "border-transparent opacity-60 hover:opacity-100"
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Form Buttons */}
                    <div className="flex items-center gap-2 pt-3 border-t border-neutral-900/60">
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs text-white font-display font-bold shadow-md active:scale-[0.98] transition-all cursor-pointer flex items-center gap-1"
                      >
                        <Save className="w-3.5 h-3.5" />
                        Save Changes
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditing(false)}
                        className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs text-neutral-400 hover:text-neutral-200 transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </motion.form>
                )}
              </div>

          </div>

          {/* Modal Footer */}
          <div className="px-6 py-4 bg-neutral-950/50 border-t border-neutral-900 text-center text-[10px] text-neutral-500 font-mono tracking-wider flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
              <div>
                CONNECTED SECURELY AS: <span className="text-neutral-300 font-bold">{email}</span>
              </div>
              <button
                onClick={() => {
                  onSignOut();
                  onClose();
                }}
                className="flex items-center gap-1 px-2.5 py-1 bg-red-950/35 hover:bg-red-900/40 border border-red-900/40 hover:border-red-500/50 text-red-400 hover:text-red-300 font-sans font-semibold text-[10px] rounded-lg tracking-normal cursor-pointer transition-all active:scale-95"
              >
                <LogOut className="w-3 h-3" />
                SIGN OUT
              </button>
            </div>
            <div>
              3D CONCEPT LAB PANEL <span className="text-cyan-500 font-bold">V1.5</span>
            </div>
          </div>
        </motion.div>

        {/* Action Micro Toast Feedback */}
        <AnimatePresence>
          {showToast && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="fixed bottom-6 z-[60] bg-indigo-950/90 text-indigo-100 px-4 py-2.5 rounded-xl border border-indigo-500/40 text-xs font-display font-medium shadow-2xl flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-indigo-400 animate-spin-slow" />
              <span>{toastMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>
        </div>
      )}
    </AnimatePresence>
  );
}
