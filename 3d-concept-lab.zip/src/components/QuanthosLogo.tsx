import React from "react";

interface QuanthosLogoProps {
  className?: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
}

export function QuanthosLogo({ className = "", size = "md" }: QuanthosLogoProps) {
  const sizeClasses = {
    xs: "w-4.5 h-4.5",
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-9 h-9",
    xl: "w-14 h-14"
  };

  return (
    <div className={`relative flex items-center justify-center ${sizeClasses[size]} ${className}`}>
      {/* Subtle outer ambient glow */}
      <div className="absolute inset-0 bg-cyan-500/5 rounded-full blur-md pointer-events-none" />
      
      {/* Exact vector replica of the uploaded atomic orbital triangle logo */}
      <svg 
        viewBox="0 0 100 100" 
        className="w-full h-full select-none pointer-events-none"
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Soft Jade-Teal Orbit Rings */}
        {/* Horizontal Ellipse */}
        <ellipse 
          cx="50" 
          cy="51" 
          rx="45" 
          ry="18" 
          stroke="#41b29a" 
          strokeWidth="3.2" 
          strokeOpacity="0.75" 
        />
        
        {/* Left Tilted Ellipse */}
        <ellipse 
          cx="50" 
          cy="51" 
          rx="45" 
          ry="18" 
          stroke="#41b29a" 
          strokeWidth="3.2" 
          strokeOpacity="0.75" 
          transform="rotate(75 50 51)" 
        />
        
        {/* Right Tilted Ellipse */}
        <ellipse 
          cx="50" 
          cy="51" 
          rx="45" 
          ry="18" 
          stroke="#41b29a" 
          strokeWidth="3.2" 
          strokeOpacity="0.75" 
          transform="rotate(105 50 51)" 
        />

        {/* The Central Cyan Triangle */}
        <polygon 
          points="50,17 21,68 79,68" 
          stroke="#3ce8cf" 
          strokeWidth="4.5" 
          strokeLinejoin="round" 
          fill="none" 
        />

        {/* Central Focus Node */}
        <circle cx="50" cy="51" r="3.5" fill="#3ce8cf" />

        {/* Bottom Left Node - Hollow Cyan with Dark Center */}
        <circle 
          cx="21" 
          cy="68" 
          r="6.5" 
          fill="#09090b" 
          stroke="#3ce8cf" 
          strokeWidth="4" 
        />

        {/* Bottom Right Node - Hollow Cyan with Dark Center */}
        <circle 
          cx="79" 
          cy="68" 
          r="6.5" 
          fill="#09090b" 
          stroke="#3ce8cf" 
          strokeWidth="4" 
        />

        {/* Top Node - Solid Glowing Gold/Orange */}
        <circle 
          cx="50" 
          cy="17" 
          r="6.5" 
          fill="#f5b041" 
        />
      </svg>
    </div>
  );
}

