import { motion, AnimatePresence } from "motion/react";
import { X, Shield, Lock, Eye, CheckCircle, Database, Server } from "lucide-react";

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PrivacyPolicyModal({ isOpen, onClose }: PrivacyPolicyModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div id="privacy-policy-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Glass backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
          />

          {/* Modal Container Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="relative w-full max-w-2xl bg-neutral-950/90 border border-neutral-900 rounded-2xl shadow-2xl p-6 md:p-8 overflow-hidden flex flex-col max-h-[85vh] z-10 text-left font-sans"
          >
            {/* Holographic Glowing Border at Top */}
            <div className="absolute -top-[1px] inset-x-12 h-[2px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />

            {/* Header */}
            <div className="flex items-center justify-between border-b border-neutral-900 pb-4 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-cyan-950/40 text-cyan-400 rounded-xl border border-cyan-500/10">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-display font-black text-white tracking-tight">
                    Privacy Policy
                  </h3>
                  <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">
                    Quanthos PCMB & Merchant Navy Lab Panel
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg bg-neutral-900/60 hover:bg-neutral-900 text-neutral-400 hover:text-neutral-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Document Content */}
            <div className="flex-1 overflow-y-auto pr-2 space-y-5 text-xs text-neutral-300 leading-relaxed custom-scrollbar">
              <p className="text-[11px] text-neutral-400 italic">
                Last updated: June 2026. This Privacy Policy documents how Quanthos manages, secures, and handles user authentication data within our unified scientific sandbox.
              </p>

              {/* SECTION 1 */}
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-white flex items-center gap-1.5 font-display">
                  <Lock className="w-3.5 h-3.5 text-indigo-400" />
                  1. Authentication & Firebase Integration
                </h4>
                <p>
                  Quanthos operates as an advanced interactive portal for <strong>PCMB (Physics, Chemistry, Mathematics, Biology)</strong> and <strong>Merchant Navy Engineering</strong>. We leverage <strong>Google Firebase Authentication</strong> to provide secure, robust login gateways.
                </p>
                <ul className="list-disc pl-5 space-y-1 text-neutral-400">
                  <li>We utilize Firebase Auth to verify credentials, allowing sign-in via Google accounts.</li>
                  <li>Neither Quanthos nor its developers store, transmit, or have access to your personal Google passwords.</li>
                  <li>Authentication tokens are parsed and handled securely via Firebase's official server-side SDKs.</li>
                </ul>
              </div>

              {/* SECTION 2 */}
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-white flex items-center gap-1.5 font-display">
                  <Database className="w-3.5 h-3.5 text-cyan-400" />
                  2. Personal Information We Collect
                </h4>
                <p>
                  We aim to minimize data collection. The only data processed by our system includes:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-neutral-400">
                  <li><strong>Basic Identity Profile:</strong> Your name, email address, and optionally profile avatar or emoji preferences.</li>
                  <li><strong>Scientific History Logs:</strong> Saved simulation variables, math models, and physics formula histories to customize your workspace experience.</li>
                  <li><strong>Local Storage Parameters:</strong> Custom sliders, constants, and sandbox properties stored client-side on your browser.</li>
                </ul>
              </div>

              {/* SECTION 3 */}
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-white flex items-center gap-1.5 font-display">
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  3. Purpose & Data Usage
                </h4>
                <p>
                  The collected information is used strictly to power the specialized components of the Laboratory Panel, including:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-neutral-400">
                  <li>Personalizing your Quanthos dashboard layout based on academic focus (e.g., PCMB or Merchant Navy mechanics).</li>
                  <li>Rendering custom 3D particle fields and mathematical constant trajectories in the Simulation Lab.</li>
                  <li>Enabling you to recall your computational histories and simulation parameter states dynamically.</li>
                </ul>
              </div>

              {/* SECTION 4 */}
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-white flex items-center gap-1.5 font-display">
                  <Server className="w-3.5 h-3.5 text-rose-400" />
                  4. Security Practices & Cookies
                </h4>
                <p>
                  All active browser sessions are protected by industry-standard encryption. We use local browser storage to persist configuration states (like dark mode and sandbox variables). This is completely local to your device and can be cleared via your browser settings at any time.
                </p>
                <p>
                  Quanthos has a <strong>strict zero-sharing policy</strong>: we never sell, lease, exchange, or distribute your email addresses, historical parameters, or profile identifiers to any third-party advertisers or commercial trackers.
                </p>
              </div>

              {/* SECTION 5 */}
              <div className="space-y-2 border-t border-neutral-900 pt-3">
                <h4 className="text-sm font-semibold text-white flex items-center gap-1.5 font-display">
                  <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                  5. Compliance & Your Consent
                </h4>
                <p>
                  By creating an account, authenticating via Google, or launching the Quanthos 3D Lab, you hereby consent to the terms outlined in this Privacy Policy.
                </p>
                <div className="p-3 bg-neutral-900/40 rounded-xl border border-neutral-900 mt-2">
                  <p className="text-[11px] text-neutral-400">
                    For privacy inquiries or technical support regarding Quanthos Laboratory system assets, please connect with <strong>Raushan Kumar</strong> via support networks.
                  </p>
                </div>
              </div>
            </div>

            {/* Footer buttons */}
            <div className="border-t border-neutral-900 pt-4 mt-4 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-850 text-neutral-300 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Acknowledge & Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
