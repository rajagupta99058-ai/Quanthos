import { ConceptSimulation } from "../types";

export const DEFAULT_PRESETS: Record<string, ConceptSimulation> = {
  lorenz: {
    topic: "Lorenz Chaotic Attractor",
    explanation: `The **Lorenz Attractor** is a system of three-dimensional ordinary differential equations originally formulated by atmospheric scientist **Edward Lorenz** in 1963. It was derived as a simplified mathematical model for atmospheric convection.

### The Physics & Chaos Theory

The Lorenz system is famous for displaying chaotic behavior under certain set constants, leading to the birth of modern **Chaos Theory** and the coining of the **Butterfly Effect** (where infinitesimal changes in initial values cause vast divergence in downstream paths).

**System equations:**
$$\\frac{dx}{dt} = \\sigma(y - x)$$
$$\\frac{dy}{dt} = x(\\rho - z) - y$$
$$\\frac{dz}{dt} = xy - \\beta z$$

### The Parameters

1. **Sigma** ($\\sigma$): Represents the *Prandtl number*, measuring liquid/air viscosity relative to thermal conductivity.
2. **Rho** ($\\rho$): Represents the *Rayleigh number*, measuring boiling convective turbulence drive.
3. **Beta** ($\\beta$): Represents physical geometric dimension ratios of the cell convection layer.
4. **Chaos threshold**: When $\\rho = 28$, $\\sigma = 10$, and $\\beta = \\frac{8}{3} \\approx 2.67$, the orbit traces two looping spiral lobes resembling butterfly wings—orbiting eternally without ever intersecting itself!`,
    controlsGuide: "Use Left-Click + Drag to rotate the viewport around the butterfly orbits. Use your Scroll Wheel to zoom, and Right-Click + Drag to pan. Drag the sliders beneath the render stage to warp physics values on-the-fly and observe chaotic transitions!",
    threeJsCode: `const width = container.clientWidth;
const height = container.clientHeight;

// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color("#050508");
scene.fog = new THREE.FogExp2("#050508", 0.007);

const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
camera.position.set(25, 30, 80);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;

// Coordinate Grid
const grid = new THREE.GridHelper(120, 40, '#ff3366', '#141424');
grid.position.y = -35;
scene.add(grid);

const axis = new THREE.AxesHelper(30);
axis.position.y = -35;
scene.add(axis);

// Lighting
const ambientLight = new THREE.AmbientLight('#22223a', 1.2);
scene.add(ambientLight);

const pointLight1 = new THREE.PointLight('#00ffff', 4, 150);
pointLight1.position.set(10, 30, 10);
scene.add(pointLight1);

const pointLight2 = new THREE.PointLight('#ff336a', 3, 150);
pointLight2.position.set(-10, -10, -10);
scene.add(pointLight2);

// Math integration variables
let sigma = currentParams.sigma !== undefined ? Number(currentParams.sigma) : 10;
let rho = currentParams.rho !== undefined ? Number(currentParams.rho) : 28;
let beta = currentParams.beta !== undefined ? Number(currentParams.beta) : 2.67;
let simSpeed = currentParams.speed !== undefined ? Number(currentParams.speed) : 1.0;

let x = 0.1;
let y = 0.0;
let z = 0.0;

const maxPoints = 25000;
const points = [];
const positions = new Float32Array(maxPoints * 3);
const colors = new Float32Array(maxPoints * 3);

// Generate template coordinate structures
for (let i = 0; i < maxPoints; i++) {
  positions[i * 3] = x;
  positions[i * 3 + 1] = y;
  positions[i * 3 + 2] = z;
}

const geometry = new THREE.BufferGeometry();
geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

const material = new THREE.LineBasicMaterial({
  vertexColors: true,
  transparent: true,
  opacity: 0.85,
  blending: THREE.AdditiveBlending,
  linewidth: 1.5
});

const line = new THREE.Line(geometry, material);
scene.add(line);

// Dynamic Particle Indicator
const glowGeom = new THREE.SphereGeometry(1.4, 16, 16);
const glowMat = new THREE.MeshBasicMaterial({ color: '#ffeb3b', transparent: true, opacity: 0.9 });
const indicator = new THREE.Mesh(glowGeom, glowMat);
scene.add(indicator);

// Create top floating math card
const topCardDiv = document.createElement('div');
topCardDiv.style.position = 'absolute';
topCardDiv.style.top = '12px';
topCardDiv.style.left = '50%';
topCardDiv.style.transform = 'translateX(-50%)';
topCardDiv.style.zIndex = '10';
topCardDiv.style.pointerEvents = 'none';
container.appendChild(topCardDiv);

// Create floating projection label for lead attractor node
const labelDiv = document.createElement('div');
labelDiv.style.position = 'absolute';
labelDiv.style.color = '#ffffff';
labelDiv.style.pointerEvents = 'none';
labelDiv.style.transform = 'translate(-50%, -100%)';
labelDiv.style.zIndex = '10';
labelDiv.style.transition = 'opacity 0.15s ease';
container.appendChild(labelDiv);

const tempV = new THREE.Vector3();

const timer = new THREE.Timer();
let animationId = null;

function animate() {
  animationId = requestAnimationFrame(animate);
  timer.update();
  const dt = Math.min(timer.getDelta(), 0.03) * simSpeed * 1.6;
  
  if (dt > 0) {
    // Lorenz system math differential integration
    const dx = sigma * (y - x) * dt;
    const dy = (x * (rho - z) - y) * dt;
    const dz = (x * y - beta * z) * dt;
    
    x += dx;
    y += dy;
    z += dz;
    
    // Feed arrays
    points.push(new THREE.Vector3(x, y - 25, z)); // Centered offset
    if (points.length > maxPoints) {
      points.shift();
    }
  }
  
  const posAttr = geometry.attributes.position;
  const colAttr = geometry.attributes.color;
  
  for (let i = 0; i < points.length; i++) {
    posAttr.setXYZ(i, points[i].x, points[i].y, points[i].z);
    
    // Glow color gradient calculated relative to local math trajectory space
    const progress = i / points.length;
    const r = 0.2 + progress * 0.8 * (Math.abs(points[i].x) / 25);
    const g = 0.1 + progress * 0.9 * (Math.abs(points[i].y + 15) / 30);
    const b = 0.5 + progress * 0.5 * (Math.abs(points[i].z) / 45);
    colAttr.setXYZ(i, Math.min(r, 1), Math.min(g, 1), Math.min(b, 1));
  }
  
  posAttr.needsUpdate = true;
  colAttr.needsUpdate = true;
  geometry.setDrawRange(0, points.length);
  
  // Position yellow leading point
  if (points.length > 0) {
    const tip = points[points.length - 1];
    indicator.position.set(tip.x, tip.y, tip.z);

    // Position lead node HTML projection label
    tempV.copy(indicator.position);
    tempV.project(camera);
    const widthHalf = container.clientWidth / 2;
    const heightHalf = container.clientHeight / 2;
    
    if (tempV.z > 1) {
      labelDiv.style.opacity = '0';
    } else {
      labelDiv.style.opacity = '1';
      const lx = (tempV.x * widthHalf) + widthHalf;
      const ly = -(tempV.y * heightHalf) + heightHalf;
      labelDiv.style.left = lx + 'px';
      labelDiv.style.top = (ly - 15) + 'px';
      labelDiv.innerHTML = 
        '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid #ffeb3b; border-radius: 6px; padding: 4px 8px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 12px rgba(0,0,0,0.5); min-width: 140px; text-shadow: 0 1px 1px rgba(0,0,0,0.8); pointer-events: none;">' +
          '<div style="font-weight: 700; font-size: 8.5px; color: #ffffff; text-transform: uppercase; tracking: 0.4px;">Attractor Node</div>' +
          '<div style="font-family: JetBrains Mono, monospace; font-size: 8px; color: #ffeb3b; font-weight: 500;">' +
            '(' + tip.x.toFixed(1) + ', ' + (tip.y + 25).toFixed(1) + ', ' + tip.z.toFixed(1) + ')' +
          '</div>' +
        '</div>';
    }
  }

  // Update Top Floating Formula Card
  topCardDiv.innerHTML = 
    '<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(8px); webkit-backdrop-filter: blur(8px); border: 1.5px solid #ff3366; border-radius: 10px; padding: 6px 12px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 6px 20px rgba(0,0,0,0.4); width: max-content; min-width: 250px; text-shadow: 0 1px 2px rgba(0,0,0,0.8); pointer-events: none;">' +
      '<div style="font-weight: 700; font-size: 11px; margin-bottom: 2px; color: #ffffff; letter-spacing: 0.4px; text-align: center;">' +
        'Lorenz Attractor Equations' +
      '</div>' +
      '<div style="font-family: JetBrains Mono, monospace; font-size: 8px; opacity: 0.8; color: #94a3b8; display: flex; gap: 8px; margin-bottom: 4px;">' +
        '<span>dx/dt=σ(y-x)</span>' +
        '<span>dy/dt=x(ρ-z)-y</span>' +
        '<span>dz/dt=xy-βz</span>' +
      '</div>' +
      '<div style="width: 100%; height: 1px; background-color: rgba(255,255,255,0.12); margin-bottom: 4px;"></div>' +
      '<div style="display: flex; gap: 8px; font-family: JetBrains Mono, monospace; font-size: 8.5px; color: #f8fafc;">' +
        '<span>σ: <strong style="color: #38bdf8;">' + sigma.toFixed(1) + '</strong></span>' +
        '<span>ρ: <strong style="color: #ff3366;">' + rho.toFixed(1) + '</strong></span>' +
        '<span>β: <strong style="color: #34d399;">' + beta.toFixed(2) + '</strong></span>' +
      '</div>' +
    '</div>';
  
  controls.update();
  renderer.render(scene, camera);
}
animate();

const resizeObserver = new ResizeObserver((entries) => {
  for (let entry of entries) {
    const w = entry.contentRect.width;
    const h = entry.contentRect.height;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
});
resizeObserver.observe(container);

return {
  updateParams: (newParams) => {
    if (newParams.sigma !== undefined) sigma = Number(newParams.sigma);
    if (newParams.rho !== undefined) rho = Number(newParams.rho);
    if (newParams.beta !== undefined) beta = Number(newParams.beta);
    if (newParams.speed !== undefined) simSpeed = Number(newParams.speed);
  },
  destroy: () => {
    cancelAnimationFrame(animationId);
    resizeObserver.disconnect();
    controls.dispose();
    renderer.dispose();
    if (renderer.domElement && renderer.domElement.parentNode) {
      renderer.domElement.parentNode.removeChild(renderer.domElement);
    }
    geometry.dispose();
    material.dispose();
    glowGeom.dispose();
    glowMat.dispose();
    if (labelDiv.parentNode) labelDiv.parentNode.removeChild(labelDiv);
    if (topCardDiv.parentNode) topCardDiv.parentNode.removeChild(topCardDiv);
  }
};`,
    interactiveParameters: [
      { name: "sigma", label: "Sigma (Convective Prandtl)", type: "slider", min: 1, max: 25, step: 0.1, default: 10 },
      { name: "rho", label: "Rho (Thermal Convection)", type: "slider", min: 5, max: 45, step: 0.1, default: 28 },
      { name: "beta", label: "Beta (Geometric aspect)", type: "slider", min: 0.5, max: 8, step: 0.05, default: 2.67 },
      { name: "speed", label: "Integration speed multiplier", type: "slider", min: 0.1, max: 3, step: 0.1, default: 1.0 },
    ],
  },
  gravity: {
    topic: "Planetary Mutual Gravity",
    explanation: `Orbital physics is governed by **Sir Isaac Newton's Law of Universal Gravitation**. It explains how planets, satellites, and astronomical bodies remain locked in balanced paths in vacuum.

### Newton's Gravity Equation

Every point mass attracts every other point mass by a force acting along the line intersecting their centers. The gravitational force ($F_g$) is proportional to the product of their masses ($m_1$ and $m_2$) and inversely proportional to the square of the distance ($r$) separating them:

$$F_g = G \\frac{m_1 m_2}{r^2}$$

And for a lighter body orbiting a massive star, the orbital acceleration ($a$) is given by:

$$a = G \\frac{M_{\\text{sun}}}{r^2}$$

### Inertia vs Gravitational Pull

A planet's orbit is a delicate, perpetual fall. The planet's velocity vector points perpendicular to the Sun's gravitational vector. If velocity is too high, the planet breaks free into deep space (escapes orbit). If too low, gravity pulls it to crash into the star.`,
    controlsGuide: "Grab the screen and rotate with Left-Click + Drag to view the orbits in 3D. Zoom with Scroll. Use the 'Planets' slider to spin up to 5 individual orbital bodies and watch their mutual orbits change as you warp the solar 'Gravitational Strength' slider active on stage!",
    threeJsCode: `const width = container.clientWidth;
const height = container.clientHeight;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#030308');
scene.fog = new THREE.FogExp2('#030308', 0.005);

const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
camera.position.set(0, 45, 80);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;

// Stellar grid helper
const grid = new THREE.GridHelper(140, 40, '#3366ff', '#0f111f');
grid.position.y = -12;
scene.add(grid);

const ambientLight = new THREE.AmbientLight('#111122', 0.7);
scene.add(ambientLight);

// Glow central Sun
const sunLight = new THREE.PointLight('#ffaa00', 4, 300);
scene.add(sunLight);

const sunGeom = new THREE.SphereGeometry(6, 32, 32);
const sunMat = new THREE.MeshBasicMaterial({ color: '#ffaa00' });
const sunMesh = new THREE.Mesh(sunGeom, sunMat);
scene.add(sunMesh);

// Stellar corona flare particle ring
const flareGeom = new THREE.RingGeometry(6.5, 9, 32);
const flareMat = new THREE.MeshBasicMaterial({ color: '#ff6600', side: THREE.DoubleSide, transparent: true, opacity: 0.35 });
const flare = new THREE.Mesh(flareGeom, flareMat);
flare.rotateX(Math.PI / 2);
scene.add(flare);

let gravityConst = currentParams.gravity !== undefined ? Number(currentParams.gravity) : 2.5;
let simSpeed = currentParams.speed !== undefined ? Number(currentParams.speed) : 1.0;
let planetCount = currentParams.planets !== undefined ? Number(currentParams.planets) : 3;

// Create top floating math card
const topCardDiv = document.createElement('div');
topCardDiv.style.position = 'absolute';
topCardDiv.style.top = '12px';
topCardDiv.style.left = '50%';
topCardDiv.style.transform = 'translateX(-50%)';
topCardDiv.style.zIndex = '10';
topCardDiv.style.pointerEvents = 'none';
container.appendChild(topCardDiv);

// Create central sun indicator label
const sunLabelDiv = document.createElement('div');
sunLabelDiv.style.position = 'absolute';
sunLabelDiv.style.pointerEvents = 'none';
sunLabelDiv.style.transform = 'translate(-50%, -100%)';
sunLabelDiv.style.zIndex = '10';
container.appendChild(sunLabelDiv);

const planets = [];
const planetColors = ['#00d2ff', '#ff3366', '#00ffcc', '#ffcc00', '#ba68c8'];

function createPlanet(index) {
  const radius = 1.0 + Math.random() * 1.5;
  const color = planetColors[index % planetColors.length];
  
  const geom = new THREE.SphereGeometry(radius, 24, 24);
  const mat = new THREE.MeshPhongMaterial({
    color: color,
    emissive: color,
    emissiveIntensity: 0.15,
    shininess: 120
  });
  const mesh = new THREE.Mesh(geom, mat);
  scene.add(mesh);
  
  // Set orbital configurations
  const dist = 16 + index * 10;
  const angle = (index * (Math.PI * 2) / 5) + Math.random() * 0.4;
  const speed = Math.sqrt((gravityConst * 15) / dist) * (0.95 + Math.random() * 0.1);
  
  const pos = new THREE.Vector3(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
  const vel = new THREE.Vector3(-Math.sin(angle) * speed, 0, Math.cos(angle) * speed);
  
  // Create orbital trail
  const trailPoints = [];
  const trailGeom = new THREE.BufferGeometry();
  const trailPositions = new Float32Array(300 * 3);
  trailGeom.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
  
  const trailMat = new THREE.LineBasicMaterial({
    color: color,
    transparent: true,
    opacity: 0.35
  });
  const trailLine = new THREE.Line(trailGeom, trailMat);
  scene.add(trailLine);

  // Floating HTML projection label for the planet
  const pLabelDiv = document.createElement('div');
  pLabelDiv.style.position = 'absolute';
  pLabelDiv.style.pointerEvents = 'none';
  pLabelDiv.style.transform = 'translate(-50%, -100%)';
  pLabelDiv.style.zIndex = '10';
  pLabelDiv.style.transition = 'opacity 0.15s ease';
  container.appendChild(pLabelDiv);
  
  return { mesh, trailGeom, trailLine, trailPoints, mass: radius * 3, pos, vel, color, radius, labelDiv: pLabelDiv };
}

// Initial planetary instances
for (let i = 0; i < planetCount; i++) {
  planets.push(createPlanet(i));
}

let animationId = null;
const timer = new THREE.Timer();
const tempV = new THREE.Vector3();

function animate() {
  animationId = requestAnimationFrame(animate);
  timer.update();
  const dt = Math.min(timer.getDelta(), 0.05) * simSpeed * 5;
  const widthHalf = container.clientWidth / 2;
  const heightHalf = container.clientHeight / 2;
  
  if (dt > 0) {
    planets.forEach(p => {
      const toSun = new THREE.Vector3(0, 0, 0).sub(p.pos);
      const distSq = toSun.lengthSq();
      const dist = Math.sqrt(distSq);
      
      if (dist > 5) {
        const forceMag = (gravityConst * 15) / distSq;
        const accel = toSun.normalize().multiplyScalar(forceMag);
        p.vel.addScaledVector(accel, dt);
      }
      
      p.pos.addScaledVector(p.vel, dt);
      p.mesh.position.copy(p.pos);
      p.mesh.rotateY(0.012);
      
      p.trailPoints.push(p.pos.clone());
      if (p.trailPoints.length > 300) p.trailPoints.shift();
      
      const posAttr = p.trailLine.geometry.attributes.position;
      for (let i = 0; i < p.trailPoints.length; i++) {
        posAttr.setXYZ(i, p.trailPoints[i].x, p.trailPoints[i].y, p.trailPoints[i].z);
      }
      posAttr.needsUpdate = true;
      p.trailLine.geometry.setDrawRange(0, p.trailPoints.length);

      // Track planet HTML label position projection
      tempV.copy(p.pos);
      tempV.y += p.radius + 1.5;
      tempV.project(camera);
      if (tempV.z > 1) {
        if (p.labelDiv) p.labelDiv.style.opacity = '0';
      } else {
        if (p.labelDiv) {
          p.labelDiv.style.opacity = '1';
          const px = (tempV.x * widthHalf) + widthHalf;
          const py = -(tempV.y * heightHalf) + heightHalf;
          p.labelDiv.style.left = px + 'px';
          p.labelDiv.style.top = py + 'px';
          p.labelDiv.innerHTML = 
            '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid ' + p.color + '; border-radius: 6px; padding: 3px 6px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffffff; pointer-events: none; text-shadow: 0 1px 1px #000; min-width: 90px; text-align: center;">' +
              '<span style="font-weight: 700; color: ' + p.color + '">Planet ' + (planets.indexOf(p) + 1) + '</span>' +
              '<span style="font-family: JetBrains Mono, monospace; font-size: 7.5px; opacity: 0.9;">(' + p.pos.x.toFixed(1) + ', ' + p.pos.y.toFixed(1) + ', ' + p.pos.z.toFixed(1) + ')</span>' +
            '</div>';
        }
      }
    });
  }
  
  sunMesh.rotateY(0.003);
  flare.rotateZ(0.002);

  // Track Sun central HTML label position projection
  tempV.set(0, 7.5, 0);
  tempV.project(camera);
  if (tempV.z > 1) {
    sunLabelDiv.style.opacity = '0';
  } else {
    sunLabelDiv.style.opacity = '1';
    const sx = (tempV.x * widthHalf) + widthHalf;
    const sy = -(tempV.y * heightHalf) + heightHalf;
    sunLabelDiv.style.left = sx + 'px';
    sunLabelDiv.style.top = sy + 'px';
    sunLabelDiv.innerHTML = 
      '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(251, 191, 36, 0.15); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid #ffaa00; border-radius: 6px; padding: 3px 6px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffeb3b; font-weight: 700; pointer-events: none; text-shadow: 0 1px 2px #000;">' +
        '<span>Sol Star (Origin)</span>' +
      '</div>';
  }

  // Update Top Floating Formula Card
  topCardDiv.innerHTML = 
    '<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(8px); webkit-backdrop-filter: blur(8px); border: 1.5px solid #ffaa00; border-radius: 10px; padding: 6px 12px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 6px 20px rgba(0,0,0,0.4); width: max-content; min-width: 240px; text-shadow: 0 1px 2px rgba(0,0,0,0.8); pointer-events: none;">' +
      '<div style="font-weight: 700; font-size: 11px; margin-bottom: 2px; color: #ffffff; letter-spacing: 0.4px; text-align: center;">' +
        'Stellar Gravity Equations' +
      '</div>' +
      '<div style="font-family: JetBrains Mono, monospace; font-size: 8px; opacity: 0.8; color: #94a3b8; display: flex; gap: 8px; margin-bottom: 4px;">' +
        '<span>Fg = G·(m₁·m₂)/r²</span>' +
        '<span>a = G·M_sun/r²</span>' +
      '</div>' +
      '<div style="width: 100%; height: 1px; background-color: rgba(255,255,255,0.12); margin-bottom: 4px;"></div>' +
      '<div style="display: flex; gap: 8px; font-family: JetBrains Mono, monospace; font-size: 8.5px; color: #f8fafc;">' +
        '<span>G: <strong style="color: #ffcc00;">' + gravityConst.toFixed(2) + '</strong></span>' +
        '<span>Active Bodies: <strong style="color: #00d2ff;">' + (planets.length + 1) + '</strong></span>' +
      '</div>' +
    '</div>';
  
  controls.update();
  renderer.render(scene, camera);
}
animate();

const resizeObserver = new ResizeObserver((entries) => {
  for (let entry of entries) {
    const w = entry.contentRect.width;
    const h = entry.contentRect.height;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
});
resizeObserver.observe(container);

return {
  updateParams: (newParams) => {
    if (newParams.gravity !== undefined) gravityConst = Number(newParams.gravity);
    if (newParams.speed !== undefined) simSpeed = Number(newParams.speed);
    
    if (newParams.planets !== undefined && Number(newParams.planets) !== planetCount) {
      const targetCount = Number(newParams.planets);
      if (targetCount > planetCount) {
        for (let i = planetCount; i < targetCount; i++) {
          planets.push(createPlanet(i));
        }
      } else {
        while (planets.length > targetCount) {
          const p = planets.pop();
          if (p) {
            scene.remove(p.mesh);
            p.mesh.geometry.dispose();
            (p.mesh.material).dispose();
            
            scene.remove(p.trailLine);
            p.trailLine.geometry.dispose();
            (p.trailLine.material).dispose();

            if (p.labelDiv && p.labelDiv.parentNode) {
              p.labelDiv.parentNode.removeChild(p.labelDiv);
            }
          }
        }
      }
      planetCount = targetCount;
    }
  },
  destroy: () => {
    cancelAnimationFrame(animationId);
    resizeObserver.disconnect();
    controls.dispose();
    renderer.dispose();
    if (renderer.domElement && renderer.domElement.parentNode) {
      renderer.domElement.parentNode.removeChild(renderer.domElement);
    }
    
    sunGeom.dispose();
    sunMat.dispose();
    flareGeom.dispose();
    flareMat.dispose();
    
    planets.forEach(p => {
      scene.remove(p.mesh);
      p.mesh.geometry.dispose();
      (p.mesh.material).dispose();
      
      scene.remove(p.trailLine);
      p.trailLine.geometry.dispose();
      (p.trailLine.material).dispose();

      if (p.labelDiv && p.labelDiv.parentNode) {
        p.labelDiv.parentNode.removeChild(p.labelDiv);
      }
    });

    if (sunLabelDiv.parentNode) sunLabelDiv.parentNode.removeChild(sunLabelDiv);
    if (topCardDiv.parentNode) topCardDiv.parentNode.removeChild(topCardDiv);
  }
};`,
    interactiveParameters: [
      { name: "gravity", label: "Gravitational Strength (G)", type: "slider", min: 0.5, max: 7.0, step: 0.1, default: 2.5 },
      { name: "planets", label: "Active Planets count", type: "slider", min: 1, max: 5, step: 1, default: 3 },
      { name: "speed", label: "Time dilation warp multiplier", type: "slider", min: 0.1, max: 2.5, step: 0.1, default: 1.0 },
    ],
  },
  wave: {
    topic: "Double-Slit Wave Interference",
    explanation: `The **Double-Slit Experiment** demonstrates the central core of quantum mechanics and physics wave mechanics: **wave-particle duality** and wave superposition.

### Wave Physics & Superposition

When a wave propagates from two distinct slit apertures, the waves expand radially. When they intersect, their amplitudes combine mathematically according to the principle of **Superposition**:

**Combined interference amplitude:**
$$A_{\\text{total}}(r_1, r_2, t) = A_1 \\cos(k r_1 - \\omega t) + A_2 \\cos(k r_2 - \\omega t)$$

- **Constructive Interference**: When crest meets crest (amplitudes combine to double the height, creating high-glowing bands where $k \\Delta r = 2n\\pi$).
- **Destructive Interference**: When crest meets trough (amplitudes subtract to zero, creating deep silent dark bands where $k \\Delta r = (2n+1)\\pi$).`,
    controlsGuide: "Observe the glowing wave propagation. Use Left-Click + Drag to rotate in 3D and see how wave peaks rise and fall. Drag the 'Freq' slider to change electromagnetic wavelengths, and adjust the 'Slit separation' slider to warp wave diffraction nodes live!",
    threeJsCode: `const width = container.clientWidth;
const height = container.clientHeight;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#030308');

const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 1000);
camera.position.set(0, 40, 50);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;

// Grid wireframe representing the water/light wave canvas
const gridX = 80;
const gridZ = 80;
const geom = new THREE.PlaneGeometry(60, 60, gridX - 1, gridZ - 1);
geom.rotateX(-Math.PI / 2);

const mat = new THREE.MeshPhongMaterial({
  color: '#00ddff',
  wireframe: true,
  side: THREE.DoubleSide,
  shininess: 80,
  specular: '#ffffff'
});

const plane = new THREE.Mesh(geom, mat);
plane.position.y = -5;
scene.add(plane);

// Dynamic lights
const ambientLight = new THREE.AmbientLight('#111126', 0.8);
scene.add(ambientLight);

const blueLight = new THREE.PointLight('#00ffff', 4, 150);
blueLight.position.set(0, 20, 0);
scene.add(blueLight);

const violetLight = new THREE.PointLight('#a000ff', 3, 100);
violetLight.position.set(0, -10, 0);
scene.add(violetLight);

let frequency = currentParams.frequency !== undefined ? Number(currentParams.frequency) : 3.5;
let separation = currentParams.separation !== undefined ? Number(currentParams.separation) : 10.0;
let speed = currentParams.speed !== undefined ? Number(currentParams.speed) : 1.0;

// Visualize slits
const slitGeom = new THREE.BoxGeometry(1.2, 3, 0.4);
const slitMat = new THREE.MeshPhongMaterial({ color: '#ff3366', emissive: '#ff3366', emissiveIntensity: 0.3 });

const slitA = new THREE.Mesh(slitGeom, slitMat);
const slitB = new THREE.Mesh(slitGeom, slitMat);
slitA.position.set(-separation/2, -5, -28);
slitB.position.set(separation/2, -5, -28);
scene.add(slitA);
scene.add(slitB);

// Create top floating math card
const topCardDiv = document.createElement('div');
topCardDiv.style.position = 'absolute';
topCardDiv.style.top = '12px';
topCardDiv.style.left = '50%';
topCardDiv.style.transform = 'translateX(-50%)';
topCardDiv.style.zIndex = '10';
topCardDiv.style.pointerEvents = 'none';
container.appendChild(topCardDiv);

// Create Slit A label
const labelA = document.createElement('div');
labelA.style.position = 'absolute';
labelA.style.pointerEvents = 'none';
labelA.style.transform = 'translate(-50%, -100%)';
labelA.style.zIndex = '10';
labelA.style.transition = 'opacity 0.15s ease';
container.appendChild(labelA);

// Create Slit B label
const labelB = document.createElement('div');
labelB.style.position = 'absolute';
labelB.style.pointerEvents = 'none';
labelB.style.transform = 'translate(-50%, -100%)';
labelB.style.zIndex = '10';
labelB.style.transition = 'opacity 0.15s ease';
container.appendChild(labelB);

const tempV = new THREE.Vector3();

const timer = new THREE.Timer();
let animationId = null;

function animate() {
  animationId = requestAnimationFrame(animate);
  timer.update();
  const time = timer.getElapsed() * speed * 3.0;
  const widthHalf = container.clientWidth / 2;
  const heightHalf = container.clientHeight / 2;
  
  // Realtime wave front mathematical superposition
  const posArr = geom.attributes.position;
  const slit1Pos = new THREE.Vector3(-separation / 2, -5, -28);
  const slit2Pos = new THREE.Vector3(separation / 2, -5, -28);
  
  for (let i = 0; i < posArr.count; i++) {
    // Current coordinate
    const x = posArr.getX(i);
    const z = posArr.getZ(i);
    
    // Distances from slits
    const d1 = Math.sqrt((x - slit1Pos.x)**2 + (z - slit1Pos.y)**2 + (plane.position.y - slit1Pos.z)**2);
    const d2 = Math.sqrt((x - slit2Pos.x)**2 + (z - slit2Pos.y)**2 + (plane.position.y - slit2Pos.z)**2);
    
    // Wave amplitudes
    const amp1 = Math.sin(d1 * (frequency * 0.15) - time) / (d1 * 0.1 + 1);
    const amp2 = Math.sin(d2 * (frequency * 0.15) - time) / (d2 * 0.1 + 1);
    
    // Combined wave envelope
    const yVal = (amp1 + amp2) * 5.5;
    posArr.setY(i, yVal);
  }
  
  posArr.needsUpdate = true;
  geom.computeVertexNormals();

  // Position Slit A html node projection
  tempV.set(-separation/2, -3.5, -28);
  tempV.project(camera);
  if (tempV.z > 1) {
    labelA.style.opacity = '0';
  } else {
    labelA.style.opacity = '1';
    const lx = (tempV.x * widthHalf) + widthHalf;
    const ly = -(tempV.y * heightHalf) + heightHalf;
    labelA.style.left = lx + 'px';
    labelA.style.top = ly + 'px';
    labelA.innerHTML = 
      '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(244, 63, 94, 0.2); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid #ff3366; border-radius: 6px; padding: 2px 5px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffffff; font-weight: 700; text-shadow: 0 1px 1px #000; white-space: nowrap;">' +
        '<span>Slit A (' + (-separation/2).toFixed(1) + ', -5.0, -28.0)</span>' +
      '</div>';
  }

  // Position Slit B html node projection
  tempV.set(separation/2, -3.5, -28);
  tempV.project(camera);
  if (tempV.z > 1) {
    labelB.style.opacity = '0';
  } else {
    labelB.style.opacity = '1';
    const lx = (tempV.x * widthHalf) + widthHalf;
    const ly = -(tempV.y * heightHalf) + heightHalf;
    labelB.style.left = lx + 'px';
    labelB.style.top = ly + 'px';
    labelB.innerHTML = 
      '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(244, 63, 94, 0.2); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid #ff3366; border-radius: 6px; padding: 2px 5px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffffff; font-weight: 700; text-shadow: 0 1px 1px #000; white-space: nowrap;">' +
        '<span>Slit B (' + (separation/2).toFixed(1) + ', -5.0, -28.0)</span>' +
      '</div>';
  }

  // Update Top Floating Formula Card
  topCardDiv.innerHTML = 
    '<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(8px); webkit-backdrop-filter: blur(8px); border: 1.5px solid #00ddff; border-radius: 10px; padding: 6px 12px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 6px 20px rgba(0,0,0,0.4); width: max-content; min-width: 250px; text-shadow: 0 1px 2px rgba(0,0,0,0.8); pointer-events: none;">' +
      '<div style="font-weight: 700; font-size: 11px; margin-bottom: 2px; color: #ffffff; letter-spacing: 0.4px; text-align: center;">' +
        'Wave Superposition Equations' +
      '</div>' +
      '<div style="font-family: JetBrains Mono, monospace; font-size: 8px; opacity: 0.8; color: #94a3b8; text-align: center; margin-bottom: 4px;">' +
        'A(r₁,r₂,t) = A₁·cos(k·r₁-ω·t) + A₂·cos(k·r₂-ω·t)' +
      '</div>' +
      '<div style="width: 100%; height: 1px; background-color: rgba(255,255,255,0.12); margin-bottom: 4px;"></div>' +
      '<div style="display: flex; gap: 8px; font-family: JetBrains Mono, monospace; font-size: 8.5px; color: #f8fafc;">' +
        '<span>Freq (ω/λ): <strong style="color: #00ddff;">' + frequency.toFixed(1) + '</strong></span>' +
        '<span>Slits: <strong style="color: #ff3366;">d = ' + separation.toFixed(1) + '</strong></span>' +
      '</div>' +
    '</div>';
  
  controls.update();
  renderer.render(scene, camera);
}
animate();

const resizeObserver = new ResizeObserver((entries) => {
  for (let entry of entries) {
    const w = entry.contentRect.width;
    const h = entry.contentRect.height;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
});
resizeObserver.observe(container);

return {
  updateParams: (newParams) => {
    if (newParams.frequency !== undefined) frequency = Number(newParams.frequency);
    if (newParams.separation !== undefined) {
      separation = Number(newParams.separation);
      slitA.position.set(-separation/2, -5, -28);
      slitB.position.set(separation/2, -5, -28);
    }
    if (newParams.speed !== undefined) speed = Number(newParams.speed);
  },
  destroy: () => {
    cancelAnimationFrame(animationId);
    resizeObserver.disconnect();
    controls.dispose();
    renderer.dispose();
    if (renderer.domElement && renderer.domElement.parentNode) {
      renderer.domElement.parentNode.removeChild(renderer.domElement);
    }
    geom.dispose();
    mat.dispose();
    slitGeom.dispose();
    slitMat.dispose();
    if (labelA.parentNode) labelA.parentNode.removeChild(labelA);
    if (labelB.parentNode) labelB.parentNode.removeChild(labelB);
    if (topCardDiv.parentNode) topCardDiv.parentNode.removeChild(topCardDiv);
  }
};`,
    interactiveParameters: [
      { name: "frequency", label: "Electromagnetic Wave Frequency", type: "slider", min: 1.0, max: 7.0, step: 0.1, default: 3.5 },
      { name: "separation", label: "Slit separation aperture (nm)", type: "slider", min: 3.0, max: 20.0, step: 0.5, default: 10.0 },
      { name: "speed", label: "Simulation kinetic speed multiplier", type: "slider", min: 0.2, max: 2.0, step: 0.1, default: 1.0 },
    ],
  },
  coulomb: {
    topic: "Coulomb's Electrostatic Force",
    explanation: `**Coulomb's Law** describes the electrostatic force of attraction or repulsion between two point charges. First published in 1785 by French physicist **Charles-Augustin de Coulomb**, it forms the backbone of electrostatics.

### The Mathematical Formula

The magnitude of the electrostatic force ($F$) between two point charges ($Q_1$ and $Q_2$) is directly proportional to the product of the charges and inversely proportional to the square of the distance ($r$) separating their centers:

$$F = k_e \\frac{Q_1 Q_2}{r^2}$$

Where:
- $F$ is the electrostatic force in Newtons ($\text{N}$)
- $Q_1, Q_2$ are the quantities of the electric charges in Coulombs ($\text{C}$)
- $r$ is the separating distance between the charges in meters ($\text{m}$)
- $k_e$ is the electrostatic Coulomb constant ($k_e \\approx 8.99 \\times 10^9 \\text{ N} \\cdot \\text{m}^2/\\text{C}^2$)

### Attraction vs. Repulsion

- **Like Charges (Repulsion)**: If $Q_1 \\cdot Q_2 > 0$, the force value is positive, and the vector points **away** from the other charge.
- **Opposite Charges (Attraction)**: If $Q_1 \\cdot Q_2 < 0$, the force value is negative, and the vector points **towards** the other charge.`,
    controlsGuide: "Orbit in 3D using Click + Drag. Use the sliders to adjust the magnitudes of Q1 and Q2, Coulomb constant k, and path radius. Watch the 3D text labels stay next to their respective charges, displaying the live calculated Coulomb force and test charge coordinate updates dynamically!",
    threeJsCode: `const width = container.clientWidth;
const height = container.clientHeight;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#030308');
scene.fog = new THREE.FogExp2('#030308', 0.006);

const camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 1000);
camera.position.set(0, 30, 48);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;

// Electric coordinate grid
const grid = new THREE.GridHelper(100, 40, '#6366f1', '#10101b');
grid.position.y = -10;
scene.add(grid);

const ambientLight = new THREE.AmbientLight('#121226', 1.0);
scene.add(ambientLight);

// Glow lighting at the source
const q1Light = new THREE.PointLight('#3b82f6', 3.5, 100);
scene.add(q1Light);

// Local state tracking variables from sliders
let q1 = currentParams.q1 !== undefined ? Number(currentParams.q1) : 10.0;
let q2 = currentParams.q2 !== undefined ? Number(currentParams.q2) : -6.0;
let kke = currentParams.k !== undefined ? Number(currentParams.k) : 8.99;
let pathRadius = currentParams.radius !== undefined ? Number(currentParams.radius) : 12.0;
let timeWarp = currentParams.speed !== undefined ? Number(currentParams.speed) : 1.0;

// Source Charge Mesh (at the origin)
const sourceGeom = new THREE.SphereGeometry(2.2, 32, 32);
const sourceMat = new THREE.MeshPhongMaterial({
  color: q1 >= 0 ? '#ff3300' : '#00aaff',
  emissive: q1 >= 0 ? '#cc1100' : '#0055ff',
  emissiveIntensity: 0.65,
  shininess: 120
});
const sourceMesh = new THREE.Mesh(sourceGeom, sourceMat);
scene.add(sourceMesh);

// Test Charge Mesh
const testGeom = new THREE.SphereGeometry(1.2, 32, 32);
const testMat = new THREE.MeshPhongMaterial({
  color: q2 >= 0 ? '#10b981' : '#ffea00',
  emissive: q2 >= 0 ? '#059669' : '#d97706',
  emissiveIntensity: 0.6,
  shininess: 100
});
const testMesh = new THREE.Mesh(testGeom, testMat);
scene.add(testMesh);

// Field connection representation line
const lineGeom = new THREE.BufferGeometry();
const lineMat = new THREE.LineDashedMaterial({
  color: '#8b5cf6',
  dashSize: 0.8,
  gapSize: 0.6
});
const linePositions = new Float32Array(2 * 3);
linePositions[0] = 0; linePositions[1] = 0; linePositions[2] = 0; // source at local origin
lineGeom.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
const connectionLine = new THREE.Line(lineGeom, lineMat);
scene.add(connectionLine);

// Force Vector representation (ArrowHelper)
const arrowDir = new THREE.Vector3(1, 0, 0);
const forceArrow = new THREE.ArrowHelper(arrowDir, new THREE.Vector3(0,0,0), 6, '#ffff00', 1.4, 0.5);
scene.add(forceArrow);

// Dynamic 3D Label Generators utilizing absolute HTML/CSS flexbox overlays
const sourceLabelDiv = document.createElement('div');
sourceLabelDiv.style.position = 'absolute';
sourceLabelDiv.style.pointerEvents = 'none';
sourceLabelDiv.style.transform = 'translate(-50%, -100%)';
sourceLabelDiv.style.zIndex = '10';
sourceLabelDiv.style.transition = 'opacity 0.15s ease';
container.appendChild(sourceLabelDiv);

const testLabelDiv = document.createElement('div');
testLabelDiv.style.position = 'absolute';
testLabelDiv.style.pointerEvents = 'none';
testLabelDiv.style.transform = 'translate(-50%, -100%)';
testLabelDiv.style.zIndex = '10';
testLabelDiv.style.transition = 'opacity 0.15s ease';
container.appendChild(testLabelDiv);

// Create top floating math card
const topCardDiv = document.createElement('div');
topCardDiv.style.position = 'absolute';
topCardDiv.style.top = '12px';
topCardDiv.style.left = '50%';
topCardDiv.style.transform = 'translateX(-50%)';
topCardDiv.style.zIndex = '10';
topCardDiv.style.pointerEvents = 'none';
container.appendChild(topCardDiv);

const tempV = new THREE.Vector3();

function updateHTMLLabelPositions(tx, ty, tz, r, forceValue, absoluteForce, isAttractive) {
  const widthHalf = container.clientWidth / 2;
  const heightHalf = container.clientHeight / 2;

  // --- SOURCE LABEL ---
  tempV.set(0, 3.2, 0); // Source mesh is at local origin
  tempV.project(camera);
  
  if (tempV.z > 1) {
    sourceLabelDiv.style.opacity = '0';
  } else {
    sourceLabelDiv.style.opacity = '1';
    const sx = (tempV.x * widthHalf) + widthHalf;
    const sy = -(tempV.y * heightHalf) + heightHalf;
    sourceLabelDiv.style.left = sx + 'px';
    sourceLabelDiv.style.top = sy + 'px';
    
    const sourceBorder = q1 >= 0 ? '#ff3300' : '#00aaff';
    sourceLabelDiv.innerHTML = 
      '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid ' + sourceBorder + '; border-radius: 6px; padding: 3px 6px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffffff; pointer-events: none; text-shadow: 0 1px 1px #000; min-width: 90px; text-align: center;">' +
        '<span style="font-weight: 700; color: ' + sourceBorder + '">Source Q₁</span>' +
        '<span style="font-family: JetBrains Mono, monospace; font-size: 7.5px; opacity: 0.9;">(0.0, 0.0, 0.0)</span>' +
      '</div>';
  }

  // --- TEST LABEL ---
  tempV.set(tx, ty + 2.0, tz); // Hover above test mesh
  tempV.project(camera);
  
  if (tempV.z > 1) {
    testLabelDiv.style.opacity = '0';
  } else {
    testLabelDiv.style.opacity = '1';
    const txVal = (tempV.x * widthHalf) + widthHalf;
    const tyVal = -(tempV.y * heightHalf) + heightHalf;
    testLabelDiv.style.left = txVal + 'px';
    testLabelDiv.style.top = tyVal + 'px';
    
    const testBorder = q2 >= 0 ? '#10b981' : '#ffea00';
    testLabelDiv.innerHTML = 
      '<div style="display: flex; flex-direction: column; align-items: center; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); webkit-backdrop-filter: blur(4px); border: 1.5px solid ' + testBorder + '; border-radius: 6px; padding: 3px 6px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 4px 10px rgba(0,0,0,0.5); font-size: 8px; color: #ffffff; pointer-events: none; text-shadow: 0 1px 1px #000; min-width: 90px; text-align: center;">' +
        '<span style="font-weight: 700; color: ' + testBorder + '">Test Q₂</span>' +
        '<span style="font-family: JetBrains Mono, monospace; font-size: 7.5px; opacity: 0.9;">(' + tx.toFixed(1) + ', ' + ty.toFixed(1) + ', ' + tz.toFixed(1) + ')</span>' +
      '</div>';
  }

  // --- TOP FLOATING MATH CARD ---
  const sourceColor = q1 >= 0 ? '#ff3300' : '#00aaff';
  const testColor = q2 >= 0 ? '#10b981' : '#ffea00';
  topCardDiv.innerHTML = 
    '<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(8px); webkit-backdrop-filter: blur(8px); border: 1.5px solid #8b5cf6; border-radius: 10px; padding: 6px 12px; font-family: Inter, system-ui, sans-serif; box-shadow: 0 6px 20px rgba(0,0,0,0.4); width: max-content; min-width: 250px; text-shadow: 0 1px 2px rgba(0,0,0,0.8); pointer-events: none;">' +
      '<div style="font-weight: 700; font-size: 11px; margin-bottom: 2px; color: #ffffff; letter-spacing: 0.4px; text-align: center;">' +
        'Coulomb Electrostatics' +
      '</div>' +
      '<div style="font-family: JetBrains Mono, monospace; font-size: 8px; opacity: 0.8; color: #94a3b8; display: flex; gap: 8px; margin-bottom: 4px;">' +
        '<span>F = k·(Q₁·Q₂)/r²</span>' +
        '<span>r = ' + r.toFixed(2) + ' m</span>' +
      '</div>' +
      '<div style="width: 100%; height: 1px; background-color: rgba(255,255,255,0.12); margin-bottom: 4px;"></div>' +
      '<div style="display: flex; gap: 10px; font-family: JetBrains Mono, monospace; font-size: 8.5px; color: #f8fafc; align-items: center;">' +
        '<span>Q₁: <strong style="color: ' + sourceColor + ';">' + (q1 >= 0 ? '+' : '') + q1.toFixed(1) + '</strong></span>' +
        '<span>Q₂: <strong style="color: ' + testColor + ';">' + (q2 >= 0 ? '+' : '') + q2.toFixed(1) + '</strong></span>' +
        '<span>Force: <strong style="color: ' + (isAttractive ? '#c084fc' : '#f87171') + ';">' + forceValue.toFixed(1) + ' N</strong></span>' +
      '</div>' +
    '</div>';
}

const timer = new THREE.Timer();
let animationId = null;

function animate() {
  animationId = requestAnimationFrame(animate);
  timer.update();
  const elapsed = timer.getElapsed() * timeWarp * 0.8;
  
  // Wavy 3D Elliptical movement of Test Charge
  const angle = elapsed;
  const tx = Math.cos(angle) * pathRadius;
  const ty = Math.sin(angle * 2.0) * (pathRadius * 0.25);
  const tz = Math.sin(angle) * pathRadius;
  
  testMesh.position.set(tx, ty, tz);
  
  // Calculate spatial properties
  const r = testMesh.position.length();
  
  // Coulomb force computation (F = k * Q1 * Q2 / r^2)
  const forceValue = (kke * q1 * q2) / (r * r);
  const absoluteForce = Math.abs(forceValue);
  
  // Update Source and Test Labels using absolute position mapping
  const isAttractive = forceValue < 0;
  updateHTMLLabelPositions(tx, ty, tz, r, forceValue, absoluteForce, isAttractive);
  
  // Update Electric Field dotted lines
  const posAttr = connectionLine.geometry.attributes.position;
  posAttr.setXYZ(1, tx, ty, tz);
  posAttr.needsUpdate = true;
  connectionLine.computeLineDistances();
  
  // Update Force vector direction & arrow limits
  const toSource = new THREE.Vector3(0, 0, 0).sub(testMesh.position).normalize();
  const direction = isAttractive ? toSource : toSource.multiplyScalar(-1);
  
  const arrowLength = Math.min(Math.max(absoluteForce * 0.8, 3.0), 20.0);
  forceArrow.setDirection(direction);
  forceArrow.setLength(arrowLength, 1.2, 0.45);
  forceArrow.position.copy(testMesh.position);
  
  // Colors vectors: Violet attraction, Teal repulsion
  const vectorColor = isAttractive ? '#d8b4fe' : '#ef4444';
  forceArrow.line.material.color.set(vectorColor);
  forceArrow.cone.material.color.set(vectorColor);
  
  // Spin objects
  sourceMesh.rotateY(0.005);
  testMesh.rotateY(0.015);
  
  controls.update();
  renderer.render(scene, camera);
}
animate();

const resizeObserver = new ResizeObserver((entries) => {
  for (let entry of entries) {
    const w = entry.contentRect.width;
    const h = entry.contentRect.height;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
});
resizeObserver.observe(container);

return {
  updateParams: (newParams) => {
    if (newParams.q1 !== undefined) {
      q1 = Number(newParams.q1);
      sourceMesh.material.color.set(q1 >= 0 ? '#ff3300' : '#00aaff');
      sourceMesh.material.emissive.set(q1 >= 0 ? '#cc1100' : '#0055ff');
    }
    if (newParams.q2 !== undefined) {
      q2 = Number(newParams.q2);
      testMesh.material.color.set(q2 >= 0 ? '#10b981' : '#ffea00');
      testMesh.material.emissive.set(q2 >= 0 ? '#059669' : '#d97706');
    }
    if (newParams.k !== undefined) kke = Number(newParams.k);
    if (newParams.radius !== undefined) pathRadius = Number(newParams.radius);
    if (newParams.speed !== undefined) timeWarp = Number(newParams.speed);
  },
  destroy: () => {
    cancelAnimationFrame(animationId);
    resizeObserver.disconnect();
    controls.dispose();
    renderer.dispose();
    if (renderer.domElement && renderer.domElement.parentNode) {
      renderer.domElement.parentNode.removeChild(renderer.domElement);
    }
    
    sourceGeom.dispose();
    sourceMat.dispose();
    testGeom.dispose();
    testMat.dispose();
    lineGeom.dispose();
    lineMat.dispose();
    
    if (sourceLabelDiv && sourceLabelDiv.parentNode) {
      sourceLabelDiv.parentNode.removeChild(sourceLabelDiv);
    }
    if (testLabelDiv && testLabelDiv.parentNode) {
      testLabelDiv.parentNode.removeChild(testLabelDiv);
    }
    if (topCardDiv && topCardDiv.parentNode) {
      topCardDiv.parentNode.removeChild(topCardDiv);
    }
    
    scene.remove(forceArrow);
    forceArrow.line.geometry.dispose();
    forceArrow.line.material.dispose();
    forceArrow.cone.geometry.dispose();
    forceArrow.cone.material.dispose();
  }
};`,
    interactiveParameters: [
      { name: "q1", label: "Source Charge Q1 magnitude", type: "slider", min: -15.0, max: 15.0, step: 0.5, default: 10.0 },
      { name: "q2", label: "Test Charge Q2 magnitude", type: "slider", min: -10.0, max: 10.0, step: 0.5, default: -6.0 },
      { name: "k", label: "Coulomb Constant (k)", type: "slider", min: 1.0, max: 15.0, step: 0.1, default: 8.99 },
      { name: "radius", label: "Elliptical Path Radius (m)", type: "slider", min: 6.0, max: 20.0, step: 0.5, default: 12.0 },
      { name: "speed", label: "Simulation kinetic speed", type: "slider", min: 0.1, max: 2.5, step: 0.1, default: 1.0 },
    ],
  },
  maritime: {
    topic: "Ship Stability & Hydrostatics (Archimedes)",
    explanation: `### Transverse Vessel Stability & Metacentric Physics
This interactive simulation models container ship hydrostatics, buoyancy forces, and transverse metacentric stability. It is designed to help **Merchant Navy and Marine Engineering** students understand how cargo configuration, vessel shape, and sea states influence stability.

#### Hydrostatic Equilibrium & Archimedes' Principle
A floating vessel operates under hydrostatic equilibrium, where gravity forces acting downwards are perfectly balanced by buoyancy forces acting upwards:

$$\\Delta = \\rho_{water} \\cdot \\nabla$$

Where:
- $\\Delta$ is ship displacement (mass).
- $\\rho_{water}$ is seawater density ($1.025 \\text{ tonnes/m}^3$).
- $\\nabla$ is submerged underwater volume.

#### Transverse Stability & Metacentric Height ($GM$)
When external waves or wind heel the ship by an angle $\\theta$, the Center of Buoyancy shifts from $B$ to $B_1$. The buoyant force acts vertically upwards through $B_1$, intersecting the centerline at the **Metacentre ($M$)**.

The stability margin is determined by the **Metacentric Height ($GM$)**:

$$GM = KB + BM - KG$$

Where:
- $KB$ is Center of Buoyancy height above the keel ($K$).
- $BM$ is the Metacentric Radius ($I_y / \\nabla$, governed by the transverse moment of inertia of the waterplane).
- $KG$ is the Center of Gravity height above the keel.

#### Stability Criteria
- **Stable ($GM > 0$)**: The righting lever $GZ = GM \\sin\\theta$ acts as a restoring torque, pulling the ship upright.
- **Unstable ($GM < 0$)**: The vessel capsizes or lists heavily because gravity and buoyancy form a capsizing moment.`,
    controlsGuide: "Orbit to inspect the hull, container stack, and forces. Adjust Ballast/Mass, Beam Width, or Sea Roughness to test buoyancy and capsize scenarios.",
    threeJsCode: `const width = container.clientWidth;
const height = container.clientHeight;
const scene = new THREE.Scene();
scene.background = new THREE.Color("#050811"); // Deep nautical night

const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
camera.position.set(0, 4, 15);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(width, height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
container.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

// Lighting representing glowing high-visibility markers
const ambLight = new THREE.AmbientLight("#112233", 1.5);
scene.add(ambLight);

const light1 = new THREE.PointLight("#00ffff", 5, 50);
light1.position.set(10, 10, 10);
scene.add(light1);

const light2 = new THREE.PointLight("#ffff00", 3, 50);
light2.position.set(-10, 5, -10);
scene.add(light2);

let ballast = currentParams.ballast !== undefined ? Number(currentParams.ballast) : 1.0;
let beamWidth = currentParams.beamWidth !== undefined ? Number(currentParams.beamWidth) : 1.6;
let seaRoughness = currentParams.seaRoughness !== undefined ? Number(currentParams.seaRoughness) : 0.8;

// Group containing the entire vessel
const shipGroup = new THREE.Group();
scene.add(shipGroup);

// Create the Ship Hull
const hullGeo = new THREE.BoxGeometry(beamWidth * 2.5, 1.2, 5.0);
const hullMat = new THREE.MeshStandardMaterial({
  color: "#1e293b",
  roughness: 0.4,
  metalness: 0.8,
  wireframe: false
});
const hull = new THREE.Mesh(hullGeo, hullMat);
hull.position.y = 0;
shipGroup.add(hull);

// Keel visual marker (bottom of hull)
const keelGeo = new THREE.BoxGeometry(0.1, 0.1, 5.2);
const keelMat = new THREE.MeshBasicMaterial({ color: "#ef4444" });
const keel = new THREE.Mesh(keelGeo, keelMat);
keel.position.y = -0.6;
shipGroup.add(keel);

// Deck Cabin / Bridge superstructure
const cabinGeo = new THREE.BoxGeometry(beamWidth * 1.8, 1.0, 1.5);
const cabinMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.5 });
const cabin = new THREE.Mesh(cabinGeo, cabinMat);
cabin.position.set(0, 1.1, -1.5);
shipGroup.add(cabin);

// Cargo containers stacked on deck (represents cargo mass distribution)
const cargoGroup = new THREE.Group();
shipGroup.add(cargoGroup);

const colors = ["#ef4444", "#3b82f6", "#10b981", "#f59e0b"];
const containersList = [];
for (let x = -1; x <= 1; x++) {
  for (let z = 0; z <= 2; z++) {
    const blockGeo = new THREE.BoxGeometry(0.5, 0.5, 1.0);
    const blockMat = new THREE.MeshStandardMaterial({
      color: colors[(x + z + 5) % colors.length],
      roughness: 0.6
    });
    const block = new THREE.Mesh(blockGeo, blockMat);
    block.position.set(x * 0.6, 0.85, z * 1.0 + 0.5);
    cargoGroup.add(block);
    containersList.push(block);
  }
}

// Sea Surface Wave Mesh
const seaGeo = new THREE.PlaneGeometry(24, 24, 30, 30);
const seaMat = new THREE.MeshStandardMaterial({
  color: "#0c4a6e",
  emissive: "#0369a1",
  roughness: 0.3,
  metalness: 0.2,
  transparent: true,
  opacity: 0.75,
  wireframe: true
});
const sea = new THREE.Mesh(seaGeo, seaMat);
sea.rotation.x = -Math.PI / 2;
sea.position.y = -0.4;
scene.add(sea);

// Visual helper points for Metacentre (M), Center of Gravity (G), Center of Buoyancy (B)
const pointGeo = new THREE.SphereGeometry(0.12, 16, 16);

const mPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#facc15" })); // Metacentre: Yellow
scene.add(mPoint);

const gPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#ef4444" })); // Center of Gravity: Red
scene.add(gPoint);

const bPoint = new THREE.Mesh(pointGeo, new THREE.MeshBasicMaterial({ color: "#06b6d4" })); // Center of Buoyancy: Cyan
scene.add(bPoint);

// Dynamic arrow helper lines
const arrowG = new THREE.ArrowHelper(
  new THREE.Vector3(0, -1, 0),
  new THREE.Vector3(0, 0, 0),
  1.5,
  "#ef4444",
  0.3,
  0.15
);
scene.add(arrowG);

const arrowB = new THREE.ArrowHelper(
  new THREE.Vector3(0, 1, 0),
  new THREE.Vector3(0, 0, 0),
  1.5,
  "#06b6d4",
  0.3,
  0.15
);
scene.add(arrowB);

// Add elegant floating overlay HUD
const topCard = document.createElement("div");
topCard.style.position = "absolute"; topCard.style.top = "12px"; topCard.style.left = "50%"; topCard.style.transform = "translateX(-50%)";
topCard.style.zIndex = "10"; topCard.style.pointerEvents = "none"; topCard.style.background = "rgba(10, 15, 30, 0.9)";
topCard.style.border = "1.5px solid #06b6d4"; topCard.style.borderRadius = "10px"; topCard.style.padding = "8px 16px";
topCard.style.fontFamily = "monospace"; topCard.style.color = "white"; topCard.style.fontSize = "11px"; topCard.style.width = "max-content";
topCard.style.boxShadow = "0 0 15px rgba(6, 182, 212, 0.4)";
container.appendChild(topCard);

let animId;
let clock = new THREE.Clock();

const resizeObserver = new ResizeObserver(() => {
  const w = container.clientWidth;
  const h = container.clientHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
});
resizeObserver.observe(container);

function draw() {
  animId = requestAnimationFrame(draw);
  const time = clock.getElapsedTime();

  // 1. Calculate wave height under the ship
  // Floating motion: heave, pitch and roll based on seaRoughness
  const heave = Math.sin(time * 1.5) * 0.1 * seaRoughness;
  const waveAngle = Math.sin(time * 1.2) * 0.15 * seaRoughness; // Rolled by waves

  // 2. Draft / vertical position is affected by ballast
  const draftOffset = -0.2 * ballast; // More ballast sinks the hull deeper
  shipGroup.position.y = draftOffset + heave;

  // 3. Metacentric stability calculations
  const KB = 0.3 * (1 + ballast); // center of buoyancy rises slightly with more load
  const BM = (1.2 * beamWidth * beamWidth) / (1.0 + ballast); // metacentric radius
  const KG = 0.5 * (1 + 0.3 * ballast); // center of gravity height.

  const GM = KB + BM - KG; // Metacentric Height

  let roll;
  let stabilityState = "STABLE";
  let stateColor = "#10b981";

  if (GM > 0) {
    const restoringFrequency = Math.sqrt(GM * 9.81 / (beamWidth * 0.8));
    roll = waveAngle + Math.sin(time * restoringFrequency) * 0.05;
    shipGroup.rotation.z = roll;
    shipGroup.rotation.x = Math.sin(time * 0.8) * 0.03 * seaRoughness; // gentle pitch
  } else {
    const listAngle = GM < -0.2 ? -Math.PI / 3.5 : -Math.PI / 6;
    roll = listAngle + Math.sin(time * 0.5) * 0.02;
    shipGroup.rotation.z = roll;
    shipGroup.rotation.x = 0.05;
    stabilityState = GM < -0.25 ? "CAPSIZED! (Unstable GM)" : "HEAVY LIST (Negative GM)";
    stateColor = "#ef4444";
  }

  // 5. Update wave mesh animation
  const posAttr = seaGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const y = posAttr.getY(i);
    const z = Math.sin(x * 0.3 + time * 1.5) * 0.15 * seaRoughness + Math.cos(y * 0.3 + time * 1.2) * 0.15 * seaRoughness;
    posAttr.setZ(i, z);
  }
  posAttr.needsUpdate = true;

  // 6. Update position of hydrostatic points: G, B, M
  const shipY = shipGroup.position.y;
  
  const worldG = new THREE.Vector3(0, KG - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
  gPoint.position.copy(worldG);

  const worldB = new THREE.Vector3(0, KB - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
  bPoint.position.copy(worldB);

  const worldM = new THREE.Vector3(0, (KB + BM) - 0.6, 0).applyMatrix4(shipGroup.matrixWorld);
  mPoint.position.copy(worldM);

  arrowG.position.copy(worldG);
  arrowB.position.copy(worldB);

  arrowG.setDirection(new THREE.Vector3(0, -1, 0));
  arrowB.setDirection(new THREE.Vector3(0, 1, 0));

  // 7. Render dynamic HUD stats
  const rollDeg = Math.abs(roll * 180 / Math.PI).toFixed(1);
  const currentDraft = (0.6 - shipY).toFixed(2);
  
  topCard.innerHTML = '<div style="font-weight:bold; font-size:12px; margin-bottom:4px; text-align:center; color:#38bdf8;">' +
       '⛴️ MERCHANT NAVY SHIP HYDROSTATICS' +
    '</div>' +
    '<div style="display:grid; grid-template-columns:100px 1fr; gap:2px;">' +
      '<span>Stability:</span><strong style="color:' + stateColor + ';">' + stabilityState + '</strong>' +
      '<span>GM Height:</span><strong>' + GM.toFixed(2) + ' m</strong>' +
      '<span>Roll Angle:</span><strong>' + rollDeg + '°</strong>' +
      '<span>Vessel Draft:</span><strong>' + currentDraft + ' m</strong>' +
      '<span>Restoring Lever (GZ):</span><strong>' + (GM * Math.sin(Math.abs(roll))).toFixed(3) + ' m</strong>' +
    '</div>' +
    '<div style="font-size:9px; color:#94a3b8; border-top:1px solid #1e293b; margin-top:6px; padding-top:4px;">' +
      '<span style="color:#ef4444;">● G (Gravity)</span> | ' +
      '<span style="color:#06b6d4;">● B (Buoyancy)</span> | ' +
      '<span style="color:#facc15;">● M (Metacentre)</span>' +
    '</div>';

  controls.update();
  renderer.render(scene, camera);
}
draw();

return {
  updateParams: (p) => {
    if (p.ballast !== undefined) {
      ballast = Number(p.ballast);
    }
    if (p.beamWidth !== undefined) {
      beamWidth = Number(p.beamWidth);
      hull.scale.x = beamWidth / 1.6;
      cabin.scale.x = beamWidth / 1.6;
      cargoGroup.scale.x = beamWidth / 1.6;
    }
    if (p.seaRoughness !== undefined) {
      seaRoughness = Number(p.seaRoughness);
    }
  },
  destroy: () => {
    cancelAnimationFrame(animId);
    resizeObserver.disconnect();
    controls.dispose();
    renderer.dispose();
    if (renderer.domElement && renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
    if (topCard && topCard.parentNode) topCard.parentNode.removeChild(topCard);
    bPoint.geometry.dispose(); bPoint.material.dispose();
    gPoint.geometry.dispose(); gPoint.material.dispose();
    mPoint.geometry.dispose(); mPoint.material.dispose();
    arrowG.dispose();
    arrowB.dispose();
    scene.traverse((obj) => {
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
        else obj.material.dispose();
      }
    });
  }
};`,
    interactiveParameters: [
      { name: "ballast", label: "Cargo Load & Ballast (Mass)", type: "slider", min: 0.2, max: 2.0, step: 0.1, default: 1.0 },
      { name: "beamWidth", label: "Hull Beam Width (M)", type: "slider", min: 0.8, max: 2.5, step: 0.1, default: 1.6 },
      { name: "seaRoughness", label: "Sea Roughness (Waves)", type: "slider", min: 0.0, max: 2.5, step: 0.1, default: 0.8 }
    ],
  },
};
